package com.example;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

public class MyTest {
	 Converter conv; 
//	 TheHelperService helpserv = new TheHelperService(); 
	 TheHelperService helpserv = Mockito.mock(TheHelperService.class);
	@Before
	public  void setUpBeforEachMethod() throws Exception{
		conv = new Converter(helpserv);
	}
	
	@Test
	public void test() {
		//fail("Not yet implemented");
		Mockito.when(helpserv.findMilesToFeetMultiplier()).thenReturn(5280);
		assertEquals(5280*2, conv.milesToFeet(2));
	//	Mockito.verify(helpserv).findMilesToFeetMultiplier();
	}
}
