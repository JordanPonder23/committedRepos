package com.example;

public class Converter {
	TheHelperService thservice; 
	
	public Converter(TheHelperService helpserv) {
		this.thservice = helpserv; 
	}
	public int milesToFeet(int i) {
		return i * 5280; 
		//thservice.findMilesToFeetMultiplier()
	}
}
