package com.example;

public class TheHelperService {
	public int findMilesToFeetMultiplier() {
		return 5281; 
	}
	public double findPi() {
		return 3.14159265;
	}
}
