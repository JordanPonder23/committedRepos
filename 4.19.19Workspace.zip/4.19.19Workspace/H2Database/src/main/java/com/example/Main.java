package com.example;

import com.example.dao.SuperVillainDao;
import com.example.model.SuperVillain;
import com.example.util.HibernateUtil;

public class Main {

	public static SuperVillainDao villdao = new SuperVillainDao();

	public static void main(String[] args) {

		insertInitialValues();

		System.out.println("All the villains: " + villdao.selectAll());

		HibernateUtil.closeSes();

		System.out.println("done");

		// System.exit(0);

	}

	public static void insertInitialValues() {

		// villains

		SuperVillain vill1=new SuperVillain("Danny Boy","Technopath",250000);

		SuperVillain vill2=new SuperVillain("Aster","FireBreath",100000);

		SuperVillain vill3=new SuperVillain("Meril","Mucus Manipulation",100000);

		SuperVillain vill4=new SuperVillain("Wile E.","Super Speed",120000);

		villdao.insert(vill1);

		villdao.insert(vill2);

		villdao.insert(vill3);

		villdao.insert(vill4);

	}

}
