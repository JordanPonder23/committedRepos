package com.example.dao;

import com.example.model.SuperVillain;

public class SuperVillainDao {

	public SuperVillainDao() {

	}

	public void insert(SuperVillain myVill) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.save(myVill);

		tx.commit();

		/* ses.close(); */

	}

	public void update(SuperVillain myVill) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.update(myVill);

		tx.commit();

		/* ses.close(); */

	}

	public SuperVillain selectbyId(int id) {

		Session ses = HibernateUtil.getSession();

		SuperVillain myVill = ses.get(SuperVillain.class, id);

		/* ses.close(); */

		return myVill;

	}

	public List<SuperVillain> selectAll() {

		Session ses = HibernateUtil.getSession();

		// List<SuperVillain> charList = ses.createQuery("from SuperVillain").list();

		List<SuperVillain> villList = ses.createCriteria(SuperVillain.class).list();

		/* ses.close(); */

		return villList;

	}

}