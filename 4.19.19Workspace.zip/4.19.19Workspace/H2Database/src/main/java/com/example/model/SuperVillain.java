package com.example.model;

@Entity
@Table(name = "Super_Villain")
public class SuperVillain {

	@Id
	@Column(name = "super_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int superId;

	@Column(name = "name", unique = true, nullable = false)
	private String name;

	@Column(name = "superpower", nullable = false)
	private String superpower;

	@Column(name = "bounty")
	private int bounty;

	public SuperVillain() {

	}

	public SuperVillain(String name, String superpower, int bounty) {

		super();

		this.name = name;

		this.superpower = superpower;

		this.bounty = bounty;

	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public String getSuperpower() {

		return superpower;

	}

	public void setSuperpower(String superpower) {

		this.superpower = superpower;

	}

	public int getBounty() {

		return bounty;

	}

	public void setBounty(int bounty) {

		this.bounty = bounty;

	}

	@Override

	public String toString() {

		return "SuperVillain [name=" + name + ", superpower=" + superpower + ", bounty= $" + bounty + "]";

	}

}