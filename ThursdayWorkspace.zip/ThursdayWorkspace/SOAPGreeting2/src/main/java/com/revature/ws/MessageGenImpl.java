package com.revature.ws;

public class MessageGenImpl {

}
