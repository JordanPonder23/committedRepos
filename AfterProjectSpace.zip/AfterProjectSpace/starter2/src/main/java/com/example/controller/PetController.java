package com.example.controller;




import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.model.Pet;

@RestController
@RequestMapping("/api")
public class PetController {
	@GetMapping("/allpets")
	public List<Pet> allPets(){
		List<Pet> pList = new ArrayList<>(); 
			pList.add(new Pet("dino" , "fart"));
			pList.add(new Pet("omasou" , "you are"));
			
		return pList;
		
	}
}
