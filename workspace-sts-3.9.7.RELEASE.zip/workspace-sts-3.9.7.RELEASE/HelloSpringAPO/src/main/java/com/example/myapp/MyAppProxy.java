package com.example.myapp;

import org.springframework.stereotype.Component;

@Component("appProxy")
public class MyAppProxy {
	
	public int drawCartoon() {
		System.out.println("drawing cartoon");
		return 3; 
	}
	public void drawNature() {
		System.out.println("drawing nature");
	}
	public void sculptPottery() {
		System.out.println("sculpt pottery");
	}
}
