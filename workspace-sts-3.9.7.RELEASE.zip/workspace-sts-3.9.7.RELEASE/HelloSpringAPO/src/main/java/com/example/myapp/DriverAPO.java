package com.example.myapp;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class DriverAPO {

	public static void main(String[] args) {
		ApplicationContext appCon = new ClassPathXmlApplicationContext("jordan.xml");
	
	MyAppProxy app = appCon.getBean("appProxy", MyAppProxy.class);
	app.drawCartoon(); 
	app.drawNature();	
	}
}
