package myhogwarts.test;

import com.daotest.dao.UserDAO;

import myhogwarts.model.Users;

public class DriverTest {

	public static void main(String[] args) {
		Users user = new Users();
		user.setFirstname("Harry");  
		user.setLastname("Potter");
		
		UserDAO udao = new UserDAO(); 
		udao.insert(user);
		System.out.println("after insert");
				
	}
}
