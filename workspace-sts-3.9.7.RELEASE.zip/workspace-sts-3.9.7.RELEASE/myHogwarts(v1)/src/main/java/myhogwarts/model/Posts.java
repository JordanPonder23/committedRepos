package myhogwarts.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table
public class Posts {
	
	@Id
	@Column(name="post_Id")
	@GeneratedValue(strategy =GenerationType.AUTO)
	private int postId;
	
	@Column(name="post_image")
	private String postImage;
	
	@Column(name="post_description")
	private String postDescription;
	
	@Column(name="post_timestamp")
	private String postTime;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinColumn(name="user_Id_FK")
	private Users userVar;
}
