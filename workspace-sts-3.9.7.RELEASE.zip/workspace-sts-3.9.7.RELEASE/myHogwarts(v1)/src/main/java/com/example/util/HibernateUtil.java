package com.example.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/*
 * Configuration (class)
 * Configuration's job is to gather information from hibernate.cfg.xml and use that information
 * to create a session factory.
 * 
 * SessionFactory (interface)
 * SessionFactory's job is to create sessions and store information on how to make connections to your database.
 * Once it is configured, its immutable 
 * 
 * Session (interface)
 * Sessions manages the connection to your database and provides create, read, update, and delete operations
 * 
 * Transaction (interface)
 * Transaction manages your transactions (and cache) must be ACID. 
 * 
		 * What does ACID stand for?
		 * Atomicity - transactions are all or nothing, you cannot have PART of a transaction happen. 
		 * Consistency - after the transaction, the database schema will be intact.
		 * Isolation - transactions cannot interfere with one another.
		 * Durability - data will persist. (be updated, is able to recover from a power outage) no data will be loss
 * 
 */

public class HibernateUtil {
	private static SessionFactory sf = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	private static Session ses;

	public static Session getSession() {

		if (ses == null)
			ses = sf.openSession();

		return ses;
	}
	
	public static void closeSes() {
		ses.close();
	}

}
