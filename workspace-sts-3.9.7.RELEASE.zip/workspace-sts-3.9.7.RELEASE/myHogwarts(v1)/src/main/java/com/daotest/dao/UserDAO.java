package com.daotest.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.util.HibernateUtil;

import myhogwarts.model.Users;

public class UserDAO {
		//create a new user - 
		public void insert(Users us) {
			System.out.println("inside user-entry insert");
			Session ses = HibernateUtil.getSession();
			System.out.println("after user-entry session creation");
			Transaction tx = ses.beginTransaction();
			System.out.println("after user-entry transaction");
			ses.persist(us);
			ses.save(us);
			tx.commit();
			//ses.close();

		}
		//select all users and return them in a list -  
		public List<Users> selectAll() {
			Session ses = HibernateUtil.getSession();

			List<Users> userList = ses.createQuery("from Users", Users.class).list();

			return userList;
		}
		
		// ~========- OPTIONAL UPDATE STUFF -========~ \\
		public void updateUserInfo (Users wizToUpdate) {
		
				Session ses = HibernateUtil.getSession();
				Transaction tx = ses.beginTransaction();
					// updates the whole-old relational object with an entirely new relational object 
				// we need some form to capture new information and also retrieve old information that we 
			 // are not overwriting.. 
				ses.update(wizToUpdate);
				tx.commit();
		}
		//in case we need to grab any of the initial/ "old" information before an update.. I don't know why or if we need this be eh. it's here. 
		public Users selectById(int id) {

			Session ses = HibernateUtil.getSession();

			Users userInfo = ses.get(Users.class, id);

			return userInfo;
		}
}
