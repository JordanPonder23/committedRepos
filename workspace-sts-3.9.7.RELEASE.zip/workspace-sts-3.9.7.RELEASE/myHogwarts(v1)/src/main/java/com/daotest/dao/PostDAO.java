package com.daotest.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.util.HibernateUtil;

import myhogwarts.model.Posts;
import myhogwarts.model.Users;


public class PostDAO {
	
	///fetch all posts for the main news feed - 
	public List<Posts> selectAll() {
		Session ses = HibernateUtil.getSession();

		List<Posts> userList = ses.createQuery("from Users", Posts.class).list();

		return userList;
	}
	//insert a new post.. 
	public void insert(Posts commentStatusTweet) {
		System.out.println("inside post insert");
		Session ses = HibernateUtil.getSession();
		System.out.println("after post session creation");
		Transaction tx = ses.beginTransaction();
		System.out.println("after post transaction");
		ses.persist(commentStatusTweet);
		ses.save(commentStatusTweet);
		tx.commit();
	}
	//grab use specific posts ( by id) we will need to grab the id from the session- 
	public List<Posts> getUserPosts(Users myUser) {
		Session ses = HibernateUtil.getSession();
		List<Posts> userList = ses.createQuery("from Users where user_id = " +myUser.getUserID(), Posts.class).list();
																											//getResultList? 
		return userList;
	}	
	// ~========- OPTIONAL UPDATE STUFF -========~ \\
			public void editPost (Posts postToUpdate) {
					Session ses = HibernateUtil.getSession();
					Transaction tx = ses.beginTransaction();
						// updates the whole-old relational object with an entirely new relational object 
					// we need some form to capture new information and also retrieve old information that we 
				 // are not overwriting.. 
					ses.update(postToUpdate);
					tx.commit();
			}
			
			//maybe we could save like previous edits of a post or something? idk. 
			public Posts selectById(int Postid) {

				Session ses = HibernateUtil.getSession();

				Posts postInfo = ses.get(Posts.class, Postid);

				return postInfo;
			}
}
