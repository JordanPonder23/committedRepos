package com.example.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;



public class ServletClass extends HttpServlet{
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) 
			throws IOException, ServletException
	{
		String name = req.getParameter("humanName");
		String password = req.getParameter("password");
	//	int phone = Integer.parseInt( req.getParameter("phone"));
		
		System.out.println(name);
		System.out.println();
		System.out.println(password);
		System.out.println();
	//	System.out.println(phone);
		
//		res.setContentType("text/html");
//		PrintWriter out = res.getWriter(); 
//		out.println("<html><body><h1>The servlet is directly talking to the client!</h1></body></html>" );
//		System.out.println("we are getting this message from inside the doGet");
		
	}				
}
