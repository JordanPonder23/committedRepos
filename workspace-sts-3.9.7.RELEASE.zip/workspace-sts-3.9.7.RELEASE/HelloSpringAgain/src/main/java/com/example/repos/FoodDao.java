package com.example.repos;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.model.Food;

@Repository("foodRepo")
public class FoodDao {
	
	@Autowired
	private SessionFactory sesfact; 
	
	public FoodDao() {
		
	}
	
	@Transactional
	public void insert(Food food) {
//		Session ses = sesfact.openSession(); 
//		Transaction tx = ses.beginTransaction(); 
		sesfact.getCurrentSession().save(food);
//		ses.save(food);
//		tx.commit(); 
//		ses.close(); 
	}
	public void update(Food food) {
		Session ses = sesfact.openSession(); 
		Transaction tx = ses.beginTransaction(); 
		ses.update(food);
		tx.commit(); 
		ses.close(); 
	}
	public Food selectById(int id) {
		Session ses = sesfact.getCurrentSession();
		Food food = ses.get(Food.class, id);
		ses.close();
		return food; 
	}
	public List<Food> selectAll(){
//		Session ses = sesfact.openSession(); 
//		
//		List<Food> foodList = ses.createQuery("from food", Food.class).list();
//		ses.close();
		return sesfact.getCurrentSession().createQuery("from Food", Food.class).list(); 
	}
}
