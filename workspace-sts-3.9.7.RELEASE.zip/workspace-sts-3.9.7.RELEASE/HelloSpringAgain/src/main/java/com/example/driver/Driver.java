package com.example.driver;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.model.Food;
import com.example.repos.FoodDao;

public class Driver {

	public static ApplicationContext appContext = 
			new ClassPathXmlApplicationContext("applicationContext.xml");
	
	public static FoodDao foodrepo= appContext.getBean("foodRepo", FoodDao.class);
	
	public static void main(String[] args) {
	Driver.insertInitialValues();
	} 
	
	public static void insertInitialValues() {
		Food food1 = new Food("Banana", 90);
		Food food2 = new Food("watever", 190);
		Food food3 = new Food("toast", 920);
		Food food4 = new Food("strokes", 120);
		FoodDao fd = new FoodDao(); 
		fd.insert(food1);
		fd.insert(food2);
		fd.insert(food3);
		fd.insert(food4);
	}

}
