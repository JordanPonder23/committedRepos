package com.kevinfite;


import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/*
 * Logging LEVELS Include: 
 * 
 * All, debug, info, warn, error, ftal, off, trace 
 * 
 * (lowest priority)							(higher priority) 
 * All < debug< info < warn < error< fatal <off
 */
public class MainDrive {
		
	final static Logger logger = Logger.getLogger(MainDrive.class);
	
	public static void main(String[] args) {
		
		logger.setLevel(Level.ALL); //different levels: ALL < Debug < info < warn < error < ftal, off < trace
		// different levels below
		if(logger.isInfoEnabled()) {
			logger.info("This is info: loggers are cool, right? Sugoi!");
			
		}
		
		logger.warn("This is a warning: it comes for me at dawn... ");
		logger.error("This is an error: pineapples don't go on pizza....", 
					new IndexOutOfBoundsException());
		logger.fatal("This is fatal... like the dragonballz live action movie ");
		logger.info("----------");
		
	}
}
//aws will hold a logger.. it will be targetted over the internet.. 