package com.example.indirectservlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class IndirectServlet extends HttpServlet {
		
	@Override 
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		res.sendRedirect("http://localhost:9001/HelloServlets/dirserv");
		
		System.out.println("in indirectServlet, GET");
	}
	@Override 
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		System.out.println("in indirectServlet, POST");

	RequestDispatcher redis = req.getRequestDispatcher("/resources/html/secondpage.html");
	redis.forward(req, res);
	
	
	}
	
	
	
	
}
