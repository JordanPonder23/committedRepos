package supes.dao;

import java.util.List;

import supes.model.superhuman;


public interface superhumandao {
	//CRUD methods only 
	//create 
	public List<superhuman> selectAllSuperHuman();
	public superhuman selectAllSuperHumanByID(int id);
	public superhuman selectAllSuperHuamnByName(String name);
	public List<superhuman> selectSuperHumansByCount(int bounty);
	//update
	public int updateSuperHuman(superhuman sh); 
	//delete
	public int deleteSuperHuman(superhuman sh);
	
	public void jointPrinter(String name); 
	
		
}
