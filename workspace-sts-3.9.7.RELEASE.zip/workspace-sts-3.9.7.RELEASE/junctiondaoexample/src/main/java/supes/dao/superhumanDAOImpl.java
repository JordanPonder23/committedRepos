package supes.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import supes.model.superhuman;

public class superhumanDAOImpl implements SuperHumanDao {



	private static String url=

			"jdbc:oracle:thin:@revychan.c4wt8faaxlgp.us-east-2.rds.amazonaws.com:1521:orcl";

		private static String username=

					"superhuman";

		private static String password=

					"p4ssw0rd";

	

	@Override

	public int insertSuperHuman(SuperHuman sh) {

		// TODO Auto-generated method stub

		return 0;

	}



	@Override

	public List<SuperHuman> selectAllSuperHumans() {

		List<SuperHuman> supes = new ArrayList<>();

		

		try(Connection conn =

				DriverManager.getConnection(url, username, password))

		{

			String sql = "SELECT * FROM superhumans";

			

			PreparedStatement ps = conn.prepareStatement(sql);

			

			ResultSet rs = ps.executeQuery();

			

			while(rs.next()) {

				supes.add(new SuperHuman(rs.getInt(1),

						rs.getString(2),

						rs.getInt(3)));

			}

			

		}catch(SQLException e) {

			e.printStackTrace();

		}

		return supes;

	}



	@Override

	public SuperHuman selectSuperHumanById(int id) {

		// TODO Auto-generated method stub

		return null;

	}



	@Override

	public SuperHuman selectSuperHumanByName(String name) {

		// TODO Auto-generated method stub

		return null;

	}



	@Override

	public List<SuperHuman> selectSuperHumansByBounty(int bounty) {

		// TODO Auto-generated method stub

		return null;

	}



	@Override

	public int updateSuperHuman(SuperHuman sh) {

		// TODO Auto-generated method stub

		return 0;

	}



	@Override

	public int deleteSuperHuman(SuperHuman sh) {

		// TODO Auto-generated method stub

		return 0;

	}



	@Override

	public void jointPrinter(String name) {

		// TODO Auto-generated method stub



	}



}