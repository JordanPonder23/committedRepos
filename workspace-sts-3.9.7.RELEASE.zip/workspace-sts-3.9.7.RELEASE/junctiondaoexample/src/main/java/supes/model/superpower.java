package supes.model;

public class superpower {
		private String spower_id; 
		private String name; 
		
		public superpower() {
			
		}

		public String getSpower_id() {
			return spower_id;
		}

		public void setSpower_id(String spower_id) {
			this.spower_id = spower_id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
		
		@Override
		public String toString() {
		
		return super.toString();
		}
}
