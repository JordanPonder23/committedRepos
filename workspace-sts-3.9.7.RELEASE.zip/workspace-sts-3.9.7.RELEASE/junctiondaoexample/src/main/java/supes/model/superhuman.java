package supes.model;

public class superhuman {
		private int shuman_id; 
		private String name; 
		private int bounty; 
		public superhuman() {
			
		}
		public int getShuman_id() {
			return shuman_id;
		}
		public void setShuman_id(int shuman_id) {
			this.shuman_id = shuman_id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getBounty() {
			return bounty;
		}
		public void setBounty(int bounty) {
			this.bounty = bounty;
		}
		
		@Override
		public String toString() {
		
		return super.toString();
		}
}
