package ACTUAL.bankAppTxt;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;

import ACTUAL.bankApp.RegLoginRun;

public class CustomerBlueprint {
	
	//String custID; 
	private static String username; 
	private static String name; 
	private String lastName; 
	private String salary; 
	private boolean house; 
	private boolean car;
	private static String password;
	
	
	CustomerBlueprint(){
		
	}
	
	//initial creation constructor for when a user creates a user-name and password that works. 
	CustomerBlueprint(String storeUsername, String storePassword){
		
	}
	
//---------------------------------	
//	public String getCustID() {
//		return custID;
//	}
//	public void setCustID(String custID) {
//		this.custID = custID;
//	}
//---------------------------------
	public  String getUsername() {
		return username;
	}
	public  void setUsername(String username) {
		CustomerBlueprint.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public boolean isHouse() {
		return house;
	}
	public void setHouse(boolean house) {
		this.house = house;
	}
	public boolean isCar() {
		return car;
	}
	public void setCar(boolean car) {
		this.car = car;
	}
	//CHECKING PASSWORD DURING REGISTERING
	boolean confirmPassword(Scanner scan, CustomerBlueprint cb) {
		System.out.println("Confirm password: ");
		String scndPrompt = scan.next(); 
		boolean confirmP = false; 
		if(scndPrompt.equals(cb.getPassword())) {
		//	System.out.println("these equal"); - prior test -
			confirmP = true; 
		}else
		{
			System.out.println("Passwords don't match. Try again. ");
			cb.setPassword("");//should pass in blankness, to clean up for another try. 
			confirmP = false; 
		}		
		
		return confirmP;
	}
				//LOGIN FUNCTIONALITY FOR CUSTOMER
	boolean credCheck(Scanner scan, CustomerBlueprint cb, RegLoginRun backUp) //!!!!! CRED CHECK WILL NEED TO BE FIXED AFTER STERIALIZATION!!
	{ 
		System.out.println("Enter Username: ");
		String usernmEntry = scan.next(); //       !!!! spaces still break this :/ 
		if(usernmEntry.length() <6) {
			System.out.println("    *I am computer and I know this is not your username.. it's too short.");
			System.out.println(" Enter a username that is at least 6 characteres: ");	
			cb.credCheck(scan, cb, backUp); //try again-
		}
		System.out.println("Enter Password: ");
		String psswrdEntry = scan.next(); //  ---        -- ^ !!
		if(psswrdEntry.length() <8) {
			System.out.println("    *I am computer and I know this is not your password.. it's too short.");
			System.out.println(" Enter a password that is at least 8 characteres: ");	
			cb.credCheck(scan, cb, backUp); //try again-
		}
		
		 //checking against currently / just created ---shit
		if(usernmEntry.equals(cb.getUsername()) & psswrdEntry.equals(cb.getPassword())) //evaluate credentials
			{
			MainExecuted mx = new MainExecuted(); 
			mx.logged(true);
			return true; 
		}
		else
		{
			return false; 
		}
	}

		String accountOptions(Scanner scan, CustomerBlueprint cb) {
			System.out.println("Withdraw      - type '1'     -- RETIRE ACCOUNT (Type '4')");
			System.out.println("Deposit        - type '2'       This option will close");
			System.out.println("Account Status  - type '3'      the account and send all");
			System.out.println(" (and history)                  assets into oblivion....");
			System.out.println("       (Logout  =- type 'e') -=");
			String initialPrompt = scan.next();
			String returnedValue ="";
			if(initialPrompt.equalsIgnoreCase("e")) {
				returnedValue ="lv";
			}else {
			//=-=-=-=-=-
			int parseAtt=0; 
			try {
			parseAtt = Integer.parseInt(initialPrompt);//<<<< 
			}
			catch (NumberFormatException nfe)
			{
				System.out.println(" ** Enter a number ");
				cb.accountOptions(scan, cb);
			}
			//====================-==--
			
			if(parseAtt == 1) {
				returnedValue = "wthDrw";
			}else if (parseAtt ==2) {
				returnedValue = "dpst";
			}
			else if(parseAtt ==4) {
				returnedValue ="trmnt";
			}else if(parseAtt ==3) {
				returnedValue ="sts";
			}
			}
			return returnedValue; //if none of the above is triggered it should return "" which will be read in control flow statement from method
									//, accountSearch, in the ReLoginRun class and will represent THIS menu (account Options, a long with an error message right above it
		}
		boolean exitCheck(String e) {
			boolean extCheck = false; 
			if(e.equalsIgnoreCase("e"))
				extCheck =true; 
			
			return extCheck;
		}
		 String readObject(String filename)
			{
			 String stringable="";
				 	boolean work = true; 
				try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename)))
				{
					Object obj = ois.readObject();  // de-serialization
				//	System.out.println(obj.toString()); //test- 
							stringable = obj.toString();		
					//System.out.println("even making it here? "); //test- 
					// returns if txt file of a particular name is found
				} 
				catch (FileNotFoundException e)
				{
					//e.printStackTrace();   <--- we don't want this to print but this is a good thing! :) 
					work = false; 
					System.out.println("");
					System.out.println("This user does not exist ");
					System.out.println("");
					// returns if a file of a particular name is not found
					RegLoginRun rlr = new RegLoginRun(); 
					Scanner scan = new Scanner(System.in); 
					rlr.customerLogin(scan, rlr);
				}
				catch (IOException e) 
				{
					e.printStackTrace();
					System.out.println("error IOException");
					 // returns if a file of a particular name is not found
				} 
				catch (ClassNotFoundException e)
				{
					//e.printStackTrace();
					System.out.println("error class not found");
					// returns if a file of a particular name is not found
				}	
}

