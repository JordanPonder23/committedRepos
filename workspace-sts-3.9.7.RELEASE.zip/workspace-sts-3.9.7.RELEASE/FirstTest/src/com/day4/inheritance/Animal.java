package com.day4.inheritance;

public class Animal 
	{
	boolean isAlive = true; 
	int height; 
	int weight;
	String color;
	
	Animal(){
		System.out.println("in the animal constructor");
	}
	
	void speak() {
		System.out.println("Make animal noises!");
		
	}
	
	
}
