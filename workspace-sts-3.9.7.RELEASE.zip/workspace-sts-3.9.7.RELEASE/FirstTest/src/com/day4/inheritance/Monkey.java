package com.day4.inheritance;
 
public class Monkey extends Animal
{
//	boolean isAlive = true; 
	int height; 
	int weight;
	String color; 
	int unique;
	
	Monkey(){
//		super(); //< always implicitly here!! 
		System.out.println("in the monkey constructor");
	}
	
	
	void speak() {
		System.out.println("Make animal noises!");
		
	}
	
}
