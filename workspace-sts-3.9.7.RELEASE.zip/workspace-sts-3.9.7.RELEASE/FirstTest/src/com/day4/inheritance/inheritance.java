package com.day4.inheritance;

public class inheritance
	{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Monkey(); 
		
		Monkey m = new Monkey();
		// java does not accept multiple inheritance.. 
	}

}
