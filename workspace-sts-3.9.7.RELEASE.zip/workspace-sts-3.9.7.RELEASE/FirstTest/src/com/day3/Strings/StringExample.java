package com.day3.Strings;

public class StringExample {

	public static void main(String[] args) {
		
		//what is a string
		/// a class that is implimented using an array of chars  ( a sequence of characters) 
		//// also a string is immutable. 
		///// immutable means that it cannot be changed. 
		////// cannot be changed. 
		/////// final is the same as const. 
		
		String str; 
		
		Object obj; // this is the most baseline object creatable 
		Object objAgain = new Object();
		//default value of an object is 'null' 
				System.out.println(objAgain);   //see the output
				
		Thread thd = new Thread(); // daemon thread? JVM stillborn state? 
		
		//two ways to create strings 
		String s ="this rightr here";
		String s2 = new String("ehllloooooo world!! xD ");
		System.out.println(s);                   //see the output
		System.out.println(s2);                  // see the output
		
		
	}
}
