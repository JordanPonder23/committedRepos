package com.day3.importing;

import com.day3.classes.Animal;
import com.day3.classes.*;// grab all of them.. 

public class importExample {

	public static void main(String[] args) {
		//we can import
		Animal an = new Animal();
		//we can call the whole package of the object-data-type
		com.day3.classes.car carVAr = new com.day3.classes.car(); 	
	}
}
