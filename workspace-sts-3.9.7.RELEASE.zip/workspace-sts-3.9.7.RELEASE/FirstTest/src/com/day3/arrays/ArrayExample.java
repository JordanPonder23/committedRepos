package com.day3.arrays;
//import com.example.BankApp.*; //<---how to important a class from another package. 
import com.homework.Q12;
public class ArrayExample {
	public static void main(String[] args) {
		//an array is a series of data entries of the same type 
		//sequential in memory. referenced per index. 
		//For example,  a series of characters. 
		//each memory space has an address to it. 
		//"stack" ----------> "heap"
		//arrays type is declared prior to iniitialization (string, int, etc).. 
		int[] arryOne = {10, 19, 9, 2};
		int Arry2[] = {1,2,3,4}; //this works too! 
		
		int[] Array3 = new int[200]; //creates an empty array with 200 spots. 
		
		//default value is 0..	
		
		// for String, Thread, HashMap, class instances and ArryList, declared arrays, the default value is NULL 
		// because they are Objects. Default Object is Null. 
		//-----BTW: 
		Q12[] value = new Q12[100]; //creates an array that can store the 
								//methods and attributes of class Q12 from package 'com.example.BankApp'
		
		//Multi Dimensional array
		int[][] arrayFour = {{1,5,6},{100,90,88}};
		int[][] ArrayFive = new int[12][20];
		
		ArrayFive[1][0] = 17;
		
		//finalize vs deconstructor 
		//finalizing an object or reference in the heap, means you need to 
		//do something with the data before the garbage collector in the
		//compiler deconstructs the data and turns it to ash!!
		//when you have a multidimensional array, the first brackets will hold "internal heap addresses" 
		// when you reference only a portion of all the dimensions of the arrays, it will return only points. 
		
		//objects always have addresses first and foremost. 
		// even if it ias a one dimensional array.ex: 
		String[] myStr = new String[5];
		//each element in this string is ACTUALLY AN ADDRESS (ex. 0x322Fh) which points to the actual value 
		//SOMEWHERE ELSE IN THE HEAP!!  
		// so the index is cited in your code, at [5] which points to a value in the HEAP (computer memory)
		// which has an ADDRESS IN IT which is '0x3487tY', for example. This address points to 
		// ANOTHER place in the HEAP that has the ACTUAL String Object stored/saved. 
		
		//println secretly goes to look at the toString().. 
		
		Object obj; //all objects are child classes of this BASE class
		
		String str; // all String 			
	}	}

