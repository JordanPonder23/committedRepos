package com.day3.classes;

/* 
 * what is .... class.. 
 * 				A blueprint for an object. 
 * 
 * What is... an object? 
 * 				A group of states (variables) and actions/ b3haviors (methods) 
 * 
 * Naming conventions of Java classes. 
 * 			variable names:
 * 						  camel case.. 
 * 			Class names: 
 * 						title case.. eg. AnimalHype, UserHistory, etc. 
 * 							nouns
 * 			Interface names: 
 * 				title case. e.g. Runnable, Comparable, etc. 
 * 					Adjetives
 * 			method names: 
 * 				camelCase.. with distinct parameters.. 
 * 				verbs
 * 			package names: 
 * 				all lower case.. 
 * 			constants: 
 * 				uppercase. e.g. RED, YELLOW, MAX_PRIORITY, etc. 
 * 
 * 
 */
public class classExampleClass {
	
	public static void main(String[] args) {
			//what is the simplest way to create an object.. 
		Animal obj = new Animal(); // creates object reference
		Animal obj2; // just sets the memory space for an object. 
		new Animal(); // the simplest way to create an object (with no reference) 
		
	//	Animal() constructs the object. creates a default constructor. 
		// there is an implicit constructor but you can create your own within the actual class
		
		//instantiating v.s. instantiating.. 
		
		int i =8;  // initializing.. giving it an initial value ( int literal) 
		Thread t = new Thread();  //instantiating. creating an object and giving the referenc variable a direction to point to this object
		// object is an instance of a class.. is an object is being created, you are instantiating that class. 
		
		car thisCar = new car("purple", "charger" ); 
		thisCar.printMyCar();
		thisCar.color = "fart color"; 
		
		car otherCar = new car("fart", "fart2", "fart3");
		otherCar.printMyCar();
	}
}
