package com.day3.classes;

//a blue print for an object. 
// an object is an instance of a class. 

public class Animal {
	//how do we give a class state. 
	
	int speed = 15;  //when a value is "hardcoded", it is a literal 
	String color = "blue-ish"; // literal string
	boolean isAlive = true; //literal boolean, etc. 
	
	//how do we give an object behavior.
	
	void walkFaster() {
		speed += 5; 
	}
	void mortality() {
		isAlive = !isAlive; // the opposite of isAlive! -----> !BooleanVariable 
	}
	
		
}
