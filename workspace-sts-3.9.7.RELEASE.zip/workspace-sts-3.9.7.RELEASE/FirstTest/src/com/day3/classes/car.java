package com.day3.classes;

public class car {
	
	boolean parked; 
	double fuel; 
	 static String color; 
	static String make; 
	static String model; 
	
	//IF there are NO other constructors... the compiler will create a no args constructor. 
	// else if there are explicit constructors with args, you have to great your own 
	// no args constructor in order for one to be included. 

	public car(){ //no args constructor. 
		
	}
	
	car(String myColor, String myModel){ //this constructor has args and is an args constructor too
		color = myColor; 
		model = myModel; 
		
		if(model =="charger") {
			make ="dodge"; 
		}
		else {
			make = "unknown"; 
		}
	}
	
	car(String myColor, String myMake, String myModel){ //this constructor has args and is an args constructor too
		color= myColor; 
		make = myMake;
		model = myModel; 
	}
	
	void printMyCar() {
		System.out.println("Make: "+make +" Model: "+ model +" Color: "+color);
	}
	
}
