package com.day6.exceptions;

public class myCustomException extends Exception {
		public myCustomException() //no args constructor
		{
			
		}
		public myCustomException(String message) {
			super(message);
		}
		public myCustomException(String message, Throwable clause ) {
			super(message, clause); 
			
		}
}
