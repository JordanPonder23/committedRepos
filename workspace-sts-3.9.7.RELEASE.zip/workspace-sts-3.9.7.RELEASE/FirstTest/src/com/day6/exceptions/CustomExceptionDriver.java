package com.day6.exceptions;

public class CustomExceptionDriver {

	public static void main(String[] args) {
		myCustomException mce = new myCustomException(); 
		//our custom exception is checked.. 
		
		MyCustomRuntimeException mcre = new MyCustomRuntimeException("muffin button"); 
		throw mcre; 
		// our customruntimeexception is unchecked..
		//MyCustomRuntimeException mcre2 = new MyCustomRuntimeException(); 
		
	}
}
