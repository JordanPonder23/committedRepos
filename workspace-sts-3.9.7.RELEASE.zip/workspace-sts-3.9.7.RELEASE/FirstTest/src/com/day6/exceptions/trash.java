package com.day6.exceptions;

public class trash {
	public static void main(String[] args) {
		
		Object obj; 
		Object obj2 = new Object(); 
		Object obj3 = new Object(); 
		
		obj = null; 
		
		
	} //garbage collector is "requested" here, by default. No longer out of reference. 
}   
