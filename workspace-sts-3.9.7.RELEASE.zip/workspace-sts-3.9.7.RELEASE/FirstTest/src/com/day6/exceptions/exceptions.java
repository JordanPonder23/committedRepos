package com.day6.exceptions;

import java.io.IOException;

public class exceptions {

	public static void main(String[] args) {
		// we do not need a try catch or a duck. 
		//throw new RuntimeException(); // an uncheck exception.. means we do not need to handle the exception
									// props it up to the JVM. you should not have to CATCH a runtime exception. 
		// run time exception typically just means that OUR LOGIC IS messed up and we need to re-factor. 
		
		try {
			System.out.println("I'm in the try block");
				throw new IOException(); 
		//	Throwable 
				
		}
		catch(IOException e) {
			System.out.println(" in the first catch block.. ");
			System.exit(0);
		}catch(Throwable e) {
			System.out.println("in the second catch block");

		}
		finally {
			System.out.println("  in the finally block");
					/// regardless of the outcome of the try block, the finally block will run.. 
					// if there is a fatal error, it will not run. eg. out of memory..  
					// if there is a system failure     eg. north korean missile attack mid-run
			
//			we use a finally when you want a code block to run no matter what
//			for example: closing an input stream regardless of whether an exception has been thrown. 
			///	MIGHT USE THIS FOR TEXT FILES ON BANK APP POSSIBLE??
			
			// THE REOOT OF ALL EXCEPTIONS is 'Throwable'.. 
			
		}
	}
}
