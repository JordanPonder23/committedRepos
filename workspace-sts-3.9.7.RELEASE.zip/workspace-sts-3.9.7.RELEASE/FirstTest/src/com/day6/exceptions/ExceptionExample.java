package com.day6.exceptions;

import java.io.FileNotFoundException;

public class ExceptionExample {

	public static void main(String[] args) {
//		All exceptions are thrown at Runtime.class 
//		Checked vs unchecked: 
//					Checked exceptions need to have a try/catch OR they need to be ducked. 
//						unchecked exceptions could have a try/catch or be duck... but they could also not. No syntax error will happen in either case. 
//						
//						Why does the "checking"? the compiler
		//----
		
//		Object obj = new Object(); 
//		//throw obj; you cannot throw any 'ol Object. 
//		
//		Throwable randomThing = new Throwable(); 
//		// unhandled.. 
//		//CANNOT have both  
//		
//		//try catch... self explanatory.. 
//		try {
//			System.out.println("I'm in the try block.. what oculd go wrong?");
//			throw randomThing ;
//		}catch(Throwable e) // the catch block is like an if statement that has a true condition when the exception is thrown.. 
//		{
//			System.out.println("well, that escalated quickly");
//			e.printStackTrace(); //prints the actual error that would have shown 
		//----
					//printStackTrace() is a debugging tool .. 
		
			//this is an example of a runtime exception not being handled. 
		// if the JVM sees the exception it terminates the application. 
//	}
//				boolean b = true; 
//				System.out.println("checkpoitn 1");
//				if(b) {
//					throw new RuntimeException(); 
//				}
//				System.out.println("checkpoint 2");//doesn't reach here
				
						//SUMMARY : 
		//methods like printStackeTrace() actually start another, "separate" thread, that runs "over" and sometimes" through" the other logic,
		// in order to complete it's job. Sometimes the "new thread" and the "original thread" will get mixed up, depending at the rate of bits on 
		// one given instance of running to another. 
			//------------------------------------=-
			/// GET COMFORTABLE WITH DEBUGGING USING EXCEPTION LINES IN CONSOLE!!!!!! Bread crumbs... 
		
		///CREATE A CUSTOM EXCEPTION!!! 
		/// CREATE A CHILD CLASS/ SUB CLASS THAT EXTENDS THE 'EXCEPTION' CLASS!!!!!!!! 
		
		
	}
	///example of custom exceptions!!!
	public static void demoTryCatchNecessity() {
	//	throw new FileNotFoundException(); 
		// you NEED to handle using a try catch OR throws declaration- 
	}
	public static void demHowToDuckResponsibility() throws FileNotFoundException { //using throws to throw.. 
			
		throw new FileNotFoundException(); 
	}
}






