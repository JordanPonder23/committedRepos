package com.day6.defaultValues;

public class ValueExample {
		
	static double d;  // default value: 0.0
	static Object obj; //default value: null
	
	public static void main(String[] args) {
		// the default values will be printed. 
			System.out.println(d);
			System.out.println(obj);
			
			double d2; 
			Object obj2; 
			// arrays, objects and static/ class scope variables receive default values. 
			// block scope and method scop eod not!! 
		}
}
