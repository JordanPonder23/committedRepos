package com.day6.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class ByteStream {

	public static void main(String[] args) {
		String filename = "./ByteFile.txt";
		//	readByteStream(filename);
			writeByteStream(filename); // create file? yes. puts it in the folder specified. 
			//  ' ./ '   < goes into the SAME FOLDER "eg. HelloJava" <from class example.   
			readThisClassFile();
	}
	static void readByteStream(String filename) {
			InputStream is =null;
		try
		{
			int i; 
			is  = new FileInputStream(filename);
			while((i = is.read()) != -1) {
				System.out.println(i + " ");
			}
		}catch(FileNotFoundException e) {
			e.printStackTrace();
			
		}catch(IOException e) {
			e.printStackTrace();
		}finally {
			//one purpose of the finally block is to close resources/ streams
			// so should we close the input stream? 
			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	static void writeByteStream(String filename) {
		//TRY WITH RESOURCES.. the resource that the try statement is opened
		//with ( eg. 'FileOutputStream' outs = new FileOutPutStream(filename); )
		// will be opened within the 'try' statement (inside the parenthesis) 
		//and automatically closes sed-resource, when it is done being used 
		// ( after the TRY block.. )
		
		try(FileOutputStream outs = new FileOutputStream(filename);) {
				outs.write(65);
				outs.write(625);
				outs.write(25);
				outs.write(95);
				outs.write(61);
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}catch(IOException e) {
			e.printStackTrace();
		}				
	}
	
	
	static void readThisClassFile() {
		
		String filename = "./bin/com/day6/io/ByteStream.class";
		try(InputStream is = new FileInputStream(filename)){
			byte[] first4 = new byte[4]; 
			is.read(first4);
			
			for(byte b: first4) {
				System.out.print(Integer.toHexString(b).substring(6));
			}
			
		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
				
	}
	
}
