package com.day5.accessmodhelper; 
import com.day5.accessmodifiers.*;

public class accmodhelper extends Ellen {
	
	void printStuff() {
		
		//when inheriting from the parent, you do not need.. 
		System.out.println(color);
	}
}
