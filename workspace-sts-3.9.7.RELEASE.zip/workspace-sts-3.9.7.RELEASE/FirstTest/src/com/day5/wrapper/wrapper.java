package com.day5.wrapper;
/*
 *  what is a wrapper class? 
 *  		it wraps "stuff" like presents. aka it is a class that 
 *  		wraps primitive types into reference objects. 
 *  
 *  a class is made up of states and behaviors.. 
 *  
 *  	each primitive data type has a wrapper class counter part
 *  Primitive::Reference 
 *  	int 	Integer
 *  	double   Double
 *  	float 	  Float
 *      char 	   Character
 *      boolean     Boolean
 *      byte         Byte
 *      short         Short
 *      long           Long
 *      -------------------- 
 */			//	  ^Title casing^
public class wrapper {
	
	public static void main(String[] args) {
		//constructing a primitive data type wrapper.. 
		Integer i = new Integer(5);
		Character c = new Character('t');
		Boolean bool = new Boolean(false);
		// and so on.. 
		System.out.println(i);// prints five. just the same. 
		int i2 = i; //putting an object into a primitive actually works for some reason. 
		
		Integer myIntWrap =99; // will actually work. 
		System.out.println(myIntWrap);// will actually show the value. 
		
		Object obj = new Object(); 
		System.out.println(obj); // this is what normally what happens.. usually objects are references.. 
		// so how, in the Integer example above, is the reference value passed into the primitive data type. 
		
		Integer anIntWrap=99; //autoboxing 
		int i3 =i; // unboxing 
		
		
	}
	
	static void method1() {
		
	}
	
}
