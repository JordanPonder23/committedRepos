package com.day5.encapsulation;
/*
 * encapsulation?
 * 			a restriction of direct access of a class's members. 
 */
public class Food {
	private  String color ="blue"; 
	int calories = 5; 
	String texture = "bumpy"; 
	boolean goodTaste = true; 
	String smell[]; 
	boolean umami = false; 
	String name ="watermelon"; 
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCalories() {
		return calories;
	}

	public void setCalories(int calories) {
		this.calories = calories;
	}

	public String getTexture() {
		return texture;
	}

	public void setTexture(String texture) {
		this.texture = texture;
	}

	public boolean isGoodTaste() {
		return goodTaste;
	}

	public void setGoodTaste(boolean goodTaste) {
		this.goodTaste = goodTaste;
	}

	public String[] getSmell() {
		return smell;
	}

	public void setSmell(String[] smell) {
		this.smell = smell;
	}

	public boolean isUmami() {
		return umami;
	}

	public void setUmami(boolean umami) {
		this.umami = umami;
	}

	
	
	void setColor(String parameter) {
		this.color = parameter; 
	}
	
	String getColor() {
		return this.color; 
	}
	
	
}
