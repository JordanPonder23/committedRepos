package com.day5.encapsulation;

public class EncapEx {

	public static void main(String[] args) {
		
		//encapsulation: restriction of direct access
		Food foo = new Food(); 
		
		System.out.println(foo.getColor());		
	}
}
