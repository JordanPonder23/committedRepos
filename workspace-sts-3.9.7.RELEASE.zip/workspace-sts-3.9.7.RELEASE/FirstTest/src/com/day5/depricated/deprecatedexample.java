package com.day5.depricated;

public class deprecatedexample {
	public static void main(String[] args) {
		deprecatedexample dEx= new deprecatedexample(); 
		
		dEx.method1();
	} 
	/*
	 * Deprecated means that the support for whatever is 
	 * deprecated has been discontinued. It still technically functi ons 
	 * for backwards compatability sake. 
	 *
	 */
	@Deprecated
	void method1() {
		System.out.println("in method 1");
	}
}
