package com.day5.accessmodifiers;

public class AccessExample {
	public static void main(String[] args) {
		
		Ellen foo = new Ellen(); 
		//System.out.println(foo.name);
		
	}
}
