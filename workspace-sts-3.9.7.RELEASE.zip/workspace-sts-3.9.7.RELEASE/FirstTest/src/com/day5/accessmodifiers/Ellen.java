package com.day5.accessmodifiers;

public class Ellen {
	
	protected String name="crab legs";
	protected String color="pink/grey";
	int calories= 5; 
	boolean cooked = false; 
	
	void cook() {
		System.out.println(" in the process of grillin'");
		cooked = true; 
		System.out.println(name);
		
	}
	
	void alive() {
		cooked=false; 
	}
	
}
