package com.homework;

public class ternaryQ10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Q10. Find the minimum of two numbers using ternary operators.
		int num1 = 18; 
		int num2 = 23;
		
		int minValue = (num1 > num2) ? num2 : num1; 
		System.out.println(minValue);
		
	}

}
// number Q10 java assignment solved! 