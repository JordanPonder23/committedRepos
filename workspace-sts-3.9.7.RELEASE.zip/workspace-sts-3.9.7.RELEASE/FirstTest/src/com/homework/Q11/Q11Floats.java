package com.homework.Q11;

public class Q11Floats {
		public float float1 = 5;
		public float float2 = 2;
}
