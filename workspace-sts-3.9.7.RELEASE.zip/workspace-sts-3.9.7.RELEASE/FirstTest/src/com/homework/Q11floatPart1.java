package com.homework;

import com.homework.Q11.Q11Floats;

public class Q11floatPart1 {

	public static void main(String[] args) {
		
		Q11Floats obj = new Q11Floats();
		
		float accessed1=	obj.float1 ;
		float accessed2= obj.float2;
	}

}
//solved?