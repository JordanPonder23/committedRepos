package com.saturday.test;

public class driver {

	public static void main(String[] args) {
		
		Anything anyChair = new Anything(); 
			System.out.println(anyChair);
				
	}

}
