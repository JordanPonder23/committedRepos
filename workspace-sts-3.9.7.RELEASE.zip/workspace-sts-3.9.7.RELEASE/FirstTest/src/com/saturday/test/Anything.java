package com.saturday.test;

public class Anything {
	
	@Override //forces the below method to spelled the exact same way as one of the classes method. (class, 'Anything' inherits toString() from parent/super Object class
	public String toString() {		
		return "anything you want. anything. "; 
	}
	
	
}
