package com.example.methods;

public class overloadingExample {
	
	public static void main(String[] args) {
		
	}
	//static prevents creating an instance of an object..! 
	static void methodOne() {
		System.out.println("there are no arguments");
	}
	
	static void methodTwo(int i) {
		System.out.println("there is an argument" +i);
	}
	
	
	//parameters are the list of variables that are setup to "be filled" by an arguement 
	//so this argument 15, is passed into methodThree, via 'methodThree(15); 
	
	// the parameter is a placeholder. 
	// method signature includes parameters 
	// so MethodOne() is considered a totally different method by the compiler than MethodOne(int num) 
	
	// each similarily named method, needs to return or take an argument of a different datatype. 
	
	static void methodOne(char i) {
		System.out.println("there are no arguments");
	}
	
	//overloading is when you have mulitple methods with the "same name" but different 
	// parameter lists.. 
	//there are three ways to change the parameter list: 
	// -change the data types
	// - change the number of parameters in the list
	// -  change the order of parameters. 
	
	
	
}
