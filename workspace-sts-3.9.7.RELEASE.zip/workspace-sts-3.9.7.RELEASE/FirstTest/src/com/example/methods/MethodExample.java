package com.example.methods;

public class MethodExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double num = 2; 		
		num = num +2;
		num = num/3; 		
		num = num +2; 
		num= num/3; 
		System.out.println(num); //instead of rewriting this a million times
		
		for(int i =0; i<1000000000; i++) {
			//we can set a for loop to run through this method like a millin times
			//just call the method 
			MethodOne(num);
		}
		
	}
	
	public static void MethodOne(double num) {
		num = num +2; 
		num= num/3; 
		System.out.println(num);
	}

}

/*  the method signature:::   
 *  
 *  		[modifier(s)]               [ return type]                [method name]        ([paremter list])
 *  public, private, static, final     string, int, void,etc.      ...method name       ex. (int intName)
 *  default, synchronized, protected                                                     ex. (otherParameter)
 *  transient, abstract, etc. 
 *{  
 *     logic here 
 *     more logic
 *     return something before the last curly bracket; 
 * } 
 * 
 */