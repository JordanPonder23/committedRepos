package com.example.primitives;

public class primitiveExamples {
/*you can make packages when creating classes.
 * just name the package at the top where you see you (default).. 
 */
	//classes are just blueprints for 'object-literals'
	public static void main(String[] arguments) {
	System.out.println("I like country music and farts ");
	System.out.println("cupcakes");		
	System.out.print("applesauce");		
	//println, adds a <br> / new line. 
	// there is an escape character that you can use to escape to a new line. 
	//ex. 
	System.out.print("new line via escape key\n");//forgot which one i was but remember there are 
	//escape keys: \b, \t, \n, \f, \r, \", \', \\
	}
	
}
