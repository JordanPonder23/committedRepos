package com.example.primitives;

public class PrimExample {
	public static void main(String[] args) {
		/*
		 * A bit is a 0 / 1
		 * A byte is 8 bits
		 * a nibble is 4 bits
		 * 
		 * byte, kylobite? 1024   = 2^10 =1024
		 * 
		 * What are the primitive data types in java?
		 * int     - four bites
		 * double  - eight bites
		 * float   - 4 bites
		 * boolean - one bit
		 * long    - 8 bites
		 * char    - 4 bite 
		 * bite    - 1 bite
		 * short   - 2 bite
		 * 
		 */
		//string is NOT a primitive ( it is an "object")
		
		//how do we declare a variable? 
		
		// like this--> "datatype" and then "variable name"
		
		int x; 
		int x2 = 16; 
		
		boolean bool = true; // a true or false value 
			// there are no falsey or truthys beyond these two in JAVA 
		byte by = 7; // a smaller space efficient integer representation
		char c='T'; // it IS an important distinction between single quotes ('') and double quotes ("") 
		// single character value, uses single-quote 
		
		
		int i = 3489; //a integer numeric value
		double d = 55.289489D; // a decimal value. 
		float f = 77.290F; // a float value. [holds a big decimal number]
		short s=15; // 2 bytes, space efficient int [range:   -32,768 and a maximum value of 32,767   ]
			long l =15L ; // 8 bytes, holds larger INTS
		
			// other primitive info: 
			double dTwo = 32.289; 
			double dThree = 75; 
			float fTwo = 88.988f;//the f at the end makes it a float. 
			float fThree = (float)88.74; // you can also force as a float this way. 
			
			int iTwo = (int)88.56; //< --- this will CUT the .56 off this to force it to be an integer. 
			
			int iThree = 802_348_222; //underscores are not saved <doesn't count as white space>   _, doesn't really exist
			
			// if you type numbers and declare them as 'char' :
			char AsciiValue = 777; //it will find the ascii value, associated with the number.. if you go above, it goes back around 
			System.out.println(AsciiValue );
			System.out.println(d);
			System.out.println(dTwo);
			System.out.println(dThree);
			System.out.println(iThree);//underscores are not saved
			
			
	}
	
}
