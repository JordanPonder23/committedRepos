package com.example.flowcontrol;

public class LoopsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			//quickly do loops but they are the same as Javascript. 
		boolean bool = false; 
		
		while(bool) {
			
		}
		for(;bool;) {
			
		}
		do {
			System.out.println("thing");
		}while(bool);
		int[] ourArray = {67,55,90};
		
		for(int p: ourArray) { //same as foreach in c#
			System.out.println(p);
		}
		
		
		
	}

}
