package com.example.flowcontrol;

public class Labels {
//nested loop example in Java.. 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			loopOne: for(int i=0; i<3; i++) {
				System.out.println("outer");
				loopTwo: 
					for(int j=0; j<3; j++){
//						if(j==1)
//							continue loopOne; 
						System.out.println("- inner");
						System.out.println("i: " + i+" j: "+j);
			}
		}
	}

}
