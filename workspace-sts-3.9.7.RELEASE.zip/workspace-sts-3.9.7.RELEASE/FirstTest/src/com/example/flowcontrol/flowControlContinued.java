package com.example.flowcontrol;

public class flowControlContinued {
	public static void main(String[] arg) {
		boolean bool = false;
		//if statements exit
		if(bool) {
			
		}else if(!bool) {
			
		}else {}
		//ternary still exists
			int x =0; 
			String s = (x<9 ? "gravy":"butterToast"); 
		String k ="edd";
		//switch and case statement
		switch(k) {
		case "johny":
			System.out.println("first case.. ed");
			break;
		case "edd":
			System.out.println("Edd (second case)"); //remember: you ALWAYS USE "" for more than one character of string
			break;
		default: 
			System.out.println("plank is here");
		}
		///output: 'ed'
		
		// you CANNOT include true/ false boolean conditions for the switch statement ex: 
		
//		String k =true;
//		//switch and case statement
//		switch(k) {
//		case true:
//			System.out.println("first case.. ed");
//			break;
//		case false:
//			System.out.println("Edd (second case)");
//			break;
//		default: 
//			System.out.println(plank is here);
//		}
//		output: no good. 
		
	}
}
