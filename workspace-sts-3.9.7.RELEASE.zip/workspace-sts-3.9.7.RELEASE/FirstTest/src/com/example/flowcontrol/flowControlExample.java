package com.example.flowcontrol;

public class flowControlExample {

	public static void main(String[] args) {
	
		//exception handling/ try catch blocks.. 
		
		int i =0; //no more falsey values. This is not a falsey... 
		
		if(method1()) {
			System.out.println("in the if statement");
		}
		else
		{
			System.out.println("in the else statement");
		}
		System.out.println("done");
		
	}
	public static boolean method1() {
		System.out.println("inside of the method");
		return true; 
	} 
	//double &&'s and double ||'s are SHORT-CIRCUIT operators 
	// if you use a single & or single |, it will compute both sides of the condition. 
	
	
	
}
