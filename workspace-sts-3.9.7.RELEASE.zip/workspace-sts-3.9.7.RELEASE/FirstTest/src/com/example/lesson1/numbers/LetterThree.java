package com.example.lesson1.numbers;

public class LetterThree {
	/*
	  Packages are used to group similar classes and/or classes that work closely together 
	  to achieve some goal* 
	 */
	//classes are just blueprints for 'object-literals'
}
