package com.day9.comparatorpractice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.day8.sorting.Student;

public class exampleComparator {

	public static void main(String[] args) {
		List<Integer> listToSort = new ArrayList<>(); 
		listToSort.add(200);
		listToSort.add(30);
		listToSort.add(910);
		listToSort.add(2);
		listToSort.add(10);
		listToSort.add(902);
		listToSort.add(4);
		
//		printListPretty(listToSort);
//		
//		Collections.sort(listToSort);
//		
//		printListPretty(listToSort);
		
		
		SortableObject sb = new SortableObject(); 
		sb.id = 2; 
		sb.name = "jordan";
	//	sb.dt = new  
		
		
	}
	static void printListPretty(List<Integer> list) {

		System.out.println("num: ");

		for(Integer stud: list) {

			System.out.println(stud);

		}

		System.out.println();

	}
}
