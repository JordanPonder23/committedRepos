package com.day9.comparatorpractice;

import java.util.Date;

public class SortableObject {
		
	int id; 
	String name; 
	 Date dt; 
		
}
