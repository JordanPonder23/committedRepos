package com.day9.threading;

public class Class {
	static String fart = "good"; 
	
	public Class() {
	//	this(fart);
	}
	
		protected Class(int fart) {
		//SUPER(); 
					
		//	fart = Integer.parseInt(fart); 
		}
}
