package com.day9.threading;

public class OneCall {

	public static void main(String[] args) {
		Class instance = new Class();
		System.out.println(instance);
		Class instance2 = new Class();
		System.out.println(instance2);
	}

}
