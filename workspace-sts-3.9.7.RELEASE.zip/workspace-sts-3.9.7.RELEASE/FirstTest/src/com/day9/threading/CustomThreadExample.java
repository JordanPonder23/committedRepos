package com.day9.threading;

/*
 * to create custom thread we must first create a class that extends the 
 * Thread class; in our custom thread we must now override the run method 
 * then instantiate our object and call the start() method. 
 * 
 * To create a custom thread we can ALSO create a class that implements Runnable
 * interface; in our custom thread we must now override the run() method; 
 * then instantiate our object; THEN createa  new generic Thread class,
 * and pass our custom class (the one that implements runnable). 
 * Finally, call the .start() method on the generic Thread class.  
 * 
 * PROS and CONS of each technique of creating a custom threaD: 
 * 
 * PROs of extending: 
 * 	less lines of code required to grab the start() method. ( it comes with the extending of 'Thread') 
 *  far easier to alter the functionality fo the Thread class when extending.. 
 *  
 * Pros of implementing: 
 * 	You do NOT use up the one slot you have to extend another class... 
 * 	makes it easier if the thread is a child class. 
 * 
 * lightweight, meaning you don't have to include unwanted methods (maybe a little faster) 
 * 
 * 
 */
public class CustomThreadExample {
	
	public static void main(String[] args) {
		//creating and launch a custom thread, by extending thread class 
		MyThread mT = new MyThread(); 
		
	//	mT.run(); can't call a method like this
		
		// gotta call it like this: 
		mT.start();
		MyRunnable mR = new MyRunnable(); 
		
		Thread th = new Thread(mR); //passing an isntance of all the methods in the custom runnable object. 
		
		th.start(); 
				
		/*
		 *the run method will NOT create a separate thread (no multi-threading) 
		 * it will simply... call a method in the CURRENT thread
		 * myThread.run(); 
		 * 
		 * The start method will FIRST create a separate thread ( multi-threading) 
		 * it will then call the run method inside the newly created thread! 
		 * 
		 */
		
		for(int i =0; i<60; i++) {
			System.out.println(""+Thread.currentThread().getName());
			
		}		
	}
}
