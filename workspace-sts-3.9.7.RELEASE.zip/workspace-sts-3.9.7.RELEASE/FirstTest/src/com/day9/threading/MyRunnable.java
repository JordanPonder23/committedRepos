package com.day9.threading;

public class MyRunnable implements Runnable{//Runnable is ONLY  functional interface.. no methods. 

	// number two way to create a thread: 
	@Override
	public void run() {
		
		for(int i =0; i<60; i++) {
			System.out.println("\t:\t"+Thread.currentThread().getName());
		}
	}
		
}
