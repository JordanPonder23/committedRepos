package com.day9.threading;

public class MyThread extends Thread{
	
	@Override
	public void run() {
		for(int i =0; i<60; i++) {
			System.out.println("\t"+Thread.currentThread().getName());
		}
	}
}
