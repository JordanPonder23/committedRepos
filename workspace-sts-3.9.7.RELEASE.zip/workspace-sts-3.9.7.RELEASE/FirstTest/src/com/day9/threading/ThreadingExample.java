package com.day9.threading;

public class ThreadingExample {

	public static void main(String[] args) throws InterruptedException {
		//How do we create a thread in java?		
		Thread th = new Thread(); 
		
		//this is how we grab the reference to the current threaed we're in - 
		Thread mainThread = Thread.currentThread(); // <<< current thread.. 
		
		boolean isDaemon = mainThread.isDaemon(); 
		System.out.println(isDaemon);
		//a thread that does not cease it's execution, after the program has ceased- 
		
		mainThread.sleep(2000);//pauses the thread for 3000 milliseconds (puts it into timeWaiting ) 
		
		String name = mainThread.getName(); 
		System.out.println("This thread's name is : " + name);
			// the name of the main thread where logic originates, runs from the 'main' and is called 'main'
		
		
	}
}
