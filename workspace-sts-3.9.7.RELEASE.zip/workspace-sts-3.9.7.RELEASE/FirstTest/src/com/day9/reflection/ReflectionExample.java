package com.day9.reflection;

import com.day9.covariance.DummyObject;

/* BIG CONCEPT!!! 
 *Reflection alllows one to view an object or primitive during runtime
 * you may also modify the object's structure during runtime.. 
 * 
 */

public class ReflectionExample {

	public static void main(String[] args) {
		DummyObject dum = new DummyObject(); 
		
		Class reflect = dum.getClass(); // grabs the class right out of the HEAP
		
		System.out.println(reflect.isPrimitive()); // returns false.. not primitive... 
		System.out.println(reflect.getSuperclass());
		System.out.println(reflect.getModifiers());

	}

}
