package com.day9.covariance;

public class SuperVillain extends SuperHuman{
	
	int minionCount; 
	
	@Override
	public String useSuperPower() {
		System.out.println("Aaah! Mahaa ha! Muwahahahaha! ");
		return "specific power used"; 
	}
}
