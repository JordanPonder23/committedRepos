package com.day9.covariance;

public class CoExample {
	public static void main(String[] args) {
		
	}
}
