package com.day9.covariance;

public class ObjectEx {
	public static void main(String[] hargs) {
		
		
		Object obj = new Object();
		//obj.toSTring(); system.out.print     Secretly and automatically this method
											// to determine what prints to the console. 
		
		//obj.equals(new Object);      // compares memory address of two objects unless it is overriden
		
		//obj.hashCode(); 				// creates a psuedo unique value 
										// determined by the object; this value is used inside of maps
		
			DummyObject one = new DummyObject(); 
			DummyObject two = new DummyObject(); 
			
			System.out.println(one);
			System.out.println(two); //actual addresses.. 
			
			System.out.println(one.hashCode()); //are not same as hashcode 
			System.out.println(two.hashCode()); //but there potential collisions..
				
			System.out.println(one==two);
			
			
			
			String three = new String("hello");
			String four = new String("hello");
		//	System.out.println(three.equal ==four.toString());
			
			
			
	}
}
