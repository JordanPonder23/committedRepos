package com.day9.covariance;

public class DummyObject {

}
