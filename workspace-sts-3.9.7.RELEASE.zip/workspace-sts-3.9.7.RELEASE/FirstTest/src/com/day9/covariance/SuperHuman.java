package com.day9.covariance;

public class SuperHuman {
		String name; 
		
		public String useSuperPower() {
			System.out.println("generic superpower!");
			
			
			
			return "powerUsed"; 
		}
}
