package com.day7.abstraction;

abstract class Trees extends Matter{
	
	abstract void method2();
}
