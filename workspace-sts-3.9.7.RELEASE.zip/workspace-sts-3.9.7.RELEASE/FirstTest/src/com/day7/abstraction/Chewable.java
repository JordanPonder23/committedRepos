package com.day7.abstraction;

public interface Chewable extends Edible {
	
}
