package com.day7.abstraction;

abstract class Matter {
	
	abstract void method1();
}
