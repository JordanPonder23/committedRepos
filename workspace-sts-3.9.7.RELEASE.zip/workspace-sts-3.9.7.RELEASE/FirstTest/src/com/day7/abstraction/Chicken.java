package com.day7.abstraction;

public class Chicken extends Food
{
		
	boolean bone; 
	boolean nugget; 
	
	boolean getNugget() {
		
		return nugget; 
	}
		
}
