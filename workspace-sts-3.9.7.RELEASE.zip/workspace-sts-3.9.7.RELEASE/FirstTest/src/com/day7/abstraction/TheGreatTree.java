package com.day7.abstraction;

public class TheGreatTree extends Trees{

	@Override
	void method2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void method1() {
		// TODO Auto-generated method stub
		
	}
	
	
}
