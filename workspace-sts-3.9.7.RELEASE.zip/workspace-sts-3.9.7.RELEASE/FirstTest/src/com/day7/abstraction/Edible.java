package com.day7.abstraction;

public interface Edible {
		
		
			
		
		
}
