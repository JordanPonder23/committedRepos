package com.day7.abstraction;

public class AbstractionExample {

	public static void main(String[] args) {

	//	Edible ed = new Edible(); 
			
	//	Food f = new Food();  <<<can no longer have this. 
		// we have made the Food class abstract, therefore 
		// it is more of a concept than an option... 
		//an abstraction class can only be used ( as a sort of interface) 
		// for child/ sub classes. 
//		Food t = new Twizzlers(); //down cast 
//		Food c = new Chicken(); 
		
		
		
	}

}
