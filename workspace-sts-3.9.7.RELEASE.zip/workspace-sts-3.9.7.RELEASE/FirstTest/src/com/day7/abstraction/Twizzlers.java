package com.day7.abstraction;

public class Twizzlers extends Food{
		String flavor; 
		int length; 
		
		String getFlavor() {
			return flavor; 
		}
}
