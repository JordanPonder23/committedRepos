package com.day7.abstraction;

public abstract class Food 
{
		String name; 
		String[] ingredients; 
		int calories; 
		
		void goBad(){
			
		}
}
