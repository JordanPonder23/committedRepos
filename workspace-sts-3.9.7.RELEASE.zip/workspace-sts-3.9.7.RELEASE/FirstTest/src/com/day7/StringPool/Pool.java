package com.day7.StringPool;

public class Pool {

	public static void main(String[] args) {
		String s1  = "hello";
		String s2 = "hello";
		String s3 = "hello";
		
		System.out.println(s1.hashCode() +" s2:"+ s2.hashCode() +" s3: "+ s3.hashCode());
		System.out.println(" ");
		
		Object obj = new Object(); 
		Object obj2 = new Object(); 
		
		System.out.println(obj.hashCode() +" obj2: " + obj2.hashCode());
		
		System.out.println(" ");
		
		String s4 = new String("hello");
		
		//when we use the new keyword, we tell the compiler ( the JVM) 
		// that we NEED TO CONSTRUCT A NEW "INSTANCE" 
		//IN THE HEAP! 
		
		//Question.. what is the hash-code based on ? (address? ) 
		//random note: hashCode() is used for bucketing in Hash 
		//implementations like HashMap, HashTable, HashSet, etc.
		
		//-------------test------------
		
		if(s1 == s2) {
			System.out.println("equal");
		}
		System.out.println(" ");
		if(s1 != s4) {
			System.out.println("not equal");
		}
		
		//=============FURTHERMORE===================
		String s5 = new String("hello");
		String s6 = new String("hello");
		
		if(s5 != s6) {
			System.out.println("       equal");
		}
		
		//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		
		
		
	}

}
