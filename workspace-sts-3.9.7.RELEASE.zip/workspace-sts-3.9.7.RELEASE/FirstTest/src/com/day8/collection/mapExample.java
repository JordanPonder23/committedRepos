package com.day8.collection;

import java.util.HashMap;
import java.util.Map;

public class mapExample {

	public static void main(String[] args) {
		//HASH MAP
		
		Map<Integer, String> HashMap = new HashMap<>(); 
		HashMap.put(44, "ngozi");
		HashMap.put(22, "kevin");//why is this returning null? 
		HashMap.put(89, "fart");
		HashMap.put(11, "fart2");
		
		System.out.println(HashMap);
		System.out.println(HashMap.size());
		System.out.println(HashMap.get(3));
		
		//Loop
		
	//	for(Entry<Integer, String> entryEg = : )
			
		
			
	}

}
