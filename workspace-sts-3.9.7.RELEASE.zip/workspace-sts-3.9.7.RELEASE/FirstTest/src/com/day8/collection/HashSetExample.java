package com.day8.collection;

import java.util.HashSet;
import java.util.Set;

public class HashSetExample {
	public static void main(String args) {
		Set<Integer> hashSet = new HashSet<>();
		hashSet.add(1);
		hashSet.add(2);
		hashSet.add(3);
		hashSet.add(2);
		hashSet.add(7);
		hashSet.add(277);
		hashSet.add(77777);
		hashSet.add(2); //should skip the second zero
		System.out.println(hashSet);
		
		//no order... leans toward order, maybe but not technically sorted. 
	}
}
