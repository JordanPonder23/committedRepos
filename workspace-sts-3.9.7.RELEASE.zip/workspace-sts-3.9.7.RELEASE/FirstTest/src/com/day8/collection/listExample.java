package com.day8.collection;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;

//JUST AS A WARNING: THERE ARE DIFFERENT "IMPORT-ROOTS" FOR LIST
//SUCH AS 'java.awt.List', for EXAMPLE
//which will screw you up because it does NOT take data types in
// the chevrons 
// eg. List<Integer> declared will throw an error if you are 
//using the import 'java.awt.List'  (JUST SOMETHING TO NOTE) 

public class listExample {
	public static void main(String[] args) {
		//ARRAYLIST
		
		List<Integer> arrayList = new ArrayList<>();
		arrayList.add(5);
		arrayList.add(2);
		arrayList.add(5);
		arrayList.add(3);
		arrayList.add(5);
		arrayList.add(1);
		
		System.out.println(arrayList);//prints all the above values, added
										/// IN THE EXACT SAME ORDER!!!! 
		
		//Iterators----
			
//		ListIterator<Integer> listIterator = arrayList.listIterator();
//		while(listIterator.hasNext()) {
//			System.out.println(listIterator.next() +" ");
//		}
//		
//		ListIterator<Integer> listIterator2 = arrayList.listIterator(arrayList.size());
//		while(listIterator2.hasPrevious()) {
//			System.out.println(listIterator2.previous() +" ");
//		}
		
		//List<Integer> linkList = new LinkedList<>(); 
		// its done the same exact way as arraylist// done. 
		//			- it's better for inserting, adding values. 
			// 		- ArrayLists are faster at itterating all the way through (or searching until a value is found) 
				
	}
}
