package com.day8.sorting;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortingExample {

	public static void main(String[] args) {
		List<String> listStr = new ArrayList<>(); 
		listStr.add("stuff"); 
		listStr.add("fart"); 
		listStr.add("fart2"); 
		listStr.add("fart3"); 
		listStr.add("fart4"); 
		
		System.out.println(listStr);
		
		Collections.sort(listStr);
		
		System.out.println(listStr);	
		///////Sorting Custom classes 
		
		List<Student> studentList = new ArrayList<>(); 
		studentList.add(new Student(3, "John", 3.5, LocalDate.of(1970, 2, 12)));

		studentList.add(new Student(17, "Amy", 3.1, LocalDate.of(1989, 1, 15)));

		studentList.add(new Student(1, "Austin", 4.0, LocalDate.of(1971, 3, 30)));

		studentList.add(new Student(2, "Katie", 2.9, LocalDate.of(1776, 12, 02)));

		studentList.add(new Student(4, "Courtney", 3.0, LocalDate.of(1004, 7, 12)));
		
		
		printListPretty(studentList);
		Collections.sort(studentList);
		printListPretty(studentList);
		//unantural ordering, via GPA as well...
		Collections.sort(studentList, new studentGPAComparator());
		printListPretty(studentList);
		//comparator is the unnatural ordering.. you have to specifically tell a sorting method
		// (or treeset/ map) to use it. If you don't specify then the sorting algorithm will use 
		// the natural ordering instead. 
		// to make it easier on yourself... 
		// the natural ordering should be declared as the most COMMON usage for your sorting necessities.. 
		// 
		// you can have as many secondary/ UNATURAL ordering comparators defined as you'd like! :) 
		// 
		// try to create a comparator for DoB and Name of the students.. 
		
	}
	static void printListPretty(List<Student> list) {

		System.out.println("Students: ");

		for(Student stud: list) {

			System.out.println(stud);

		}

		System.out.println();

	}
}
