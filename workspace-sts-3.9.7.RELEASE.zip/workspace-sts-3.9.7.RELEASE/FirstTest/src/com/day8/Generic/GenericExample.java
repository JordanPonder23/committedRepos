package com.day8.Generic;

//when it comes to classes inside of classes, only one can be public. 

/*
 * when instantiating a generic object must provide the datatype, 
 * from that point that SPECIFIC object will always be that datatype. But 
 * other instances from the same generic class can be other datatypes. 
 * (each individiaul instance can NOT change its datatype, however. 
 */
class GenericClass<B> {
	private B value;

	public GenericClass(B value) {
		this.value = value;
	}

	public B getValue() {
		return value;
	}
}

public class GenericExample {

	public static void main(String[] args) {
//		GenericClass<String> firstEx = new GenericClass<String>("hello");
//
//		Object obj = new Thread();
//		System.out.println(obj instanceof Thread);// the instance of returns a boolean value.
//		// it determines the type. Compares type of object to right-hand type to compare
//		// the angle brackets offer compile time safety.. probably used more for development
		
		GenericClass<Object> firstEx = new GenericClass<>("MyHello");	
		System.out.println(firstEx.getValue() instanceof String); // will work!
		
		
		
	}

	/*
	 * Suppose we have a class hierarchy :
	 * 
	 * Animal {avgWeight = 10; }
	 * 
	 * Monkey Wolf Turtle
	 */

//	//we could have many methods that intake each animal
//	void method1(Monkey mm) {}
//	void method1(Wolf w) {}
//	void method1(Turtle t){	}
//		//void method1 (...an so on...) 
//	
//	//OR we can have one method that takes in an animal parent class
//	void method1(Animal an ) {}
//	
//	//Now suppose.... each specific animal has shadowed avgWeight. 
//		
//	/* 						Animal {avgWeight = 10; }
//	 * 	
//	 * Monkey{avgWeight=150}	Wolf{avgWeight=100} 	Turtle{avgWeight=200}    ...and
//	 */
//	void method1(Animal an) {
//		//an.avgWeight will only fetch the avg weight that already exists in the Animal/ parent class. 
//		// but if you want the individual weight.. 
//		
//	}
//	

}
