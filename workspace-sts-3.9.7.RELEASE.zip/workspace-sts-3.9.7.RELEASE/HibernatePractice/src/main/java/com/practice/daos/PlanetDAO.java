package com.practice.daos;

import java.util.List;

import org.hibernate.Session;

import org.hibernate.Transaction;

import com.example.util.HibernateUtil;
import com.practice.model.Planet;


public class PlanetDAO {

	public PlanetDAO() {

	}

	public void insert(Planet planet) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.save(planet);

		tx.commit();

	}

	public void update(Planet planet) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.update(planet);

		tx.commit();

	}

	public Planet selectById(int id) {

		Session ses = HibernateUtil.getSession();

		Planet planet = ses.get(Planet.class, id);

		return planet;

	}

	public Planet selectByName(String name) {

		return null;

	}

	public List<Planet> selectAll() {

		Session ses = HibernateUtil.getSession();

		List<Planet> planetList =

				ses.createQuery("from Planet",

						Planet.class).list();

		return planetList;

	}

}
