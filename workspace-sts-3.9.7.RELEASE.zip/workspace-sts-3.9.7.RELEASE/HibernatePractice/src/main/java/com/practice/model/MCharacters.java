package com.practice.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;

import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "movie")
public class MCharacters {

	@Id
	@Column(name = "char_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int char_id;

	@Column(name = "name", nullable = false)
	private String name;
	@Column(name = "role")
	private String role;
	
	@Column(name = "gender")
	private String gender;
	
	@ManyToMany(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	 private List<Movies> movieCharacters;

	public int getChar_id() {
		return char_id;
	}

	public void setChar_id(int char_id) {
		this.char_id = char_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<Movies> getMovieCharacters() {
		return movieCharacters;
	}

	public void setMovieCharacters(List<Movies> movieCharacters) {
		this.movieCharacters = movieCharacters;
	}
	
	public MCharacters() {
		
	}

	public MCharacters(String name, String role, String gender, List<Movies> movieCharacters) {
		super();
		this.name = name;
		this.role = role;
		this.gender = gender;
		this.movieCharacters = movieCharacters;
	}
	
	

}
