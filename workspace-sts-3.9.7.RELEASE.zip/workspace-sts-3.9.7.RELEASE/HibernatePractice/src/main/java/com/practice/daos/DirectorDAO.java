package com.practice.daos;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.util.HibernateUtil;
import com.practice.model.Directors;
import com.practice.model.MCharacters;

public class DirectorDAO {

	public void insert(Directors director) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.save(director);

		tx.commit();

		// ses.close();

	}

	public void update(Directors director) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.update(director);

		tx.commit();

		// ses.close();

	}

	public Directors selectById(int id) {

		Session ses = HibernateUtil.getSession();

		Directors director = ses.get(Directors.class, id);

		// ses.close();

		return director;

	}

	public Directors selectByName(String name) {

		return null;

	}

	public List<Directors> selectAll() {

		Session ses = HibernateUtil.getSession();

		List<Directors> directorList = ses.createQuery("from Directors", Directors.class).list();

		// ses.close();

		return directorList;

	}

}
