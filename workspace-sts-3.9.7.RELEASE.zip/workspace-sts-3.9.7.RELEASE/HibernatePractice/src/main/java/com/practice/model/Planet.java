package com.practice.model;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;

import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "planet")
public class Planet {

	@Id
	@Column(name = "planet_id")
	@GeneratedValue(strategy = GenerationType.AUTO)

	private int planet_id;

	@Column(name = "name")
	private String name;
	
	@OneToOne(mappedBy = "planet", fetch = FetchType.LAZY)
	Movies movie =new Movies();

	public int getPlanet_id() {
		return planet_id;
	}

	public void setPlanet_id(int planet_id) {
		this.planet_id = planet_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Movies getMovie() {
		return movie;
	}

	public void setMovie(Movies movie) {
		this.movie = movie;
	}
	
	public Planet() {

	}

	public Planet(String name, Movies movie) {
		super();
		this.name = name;
		this.movie = movie;
	}
	

}