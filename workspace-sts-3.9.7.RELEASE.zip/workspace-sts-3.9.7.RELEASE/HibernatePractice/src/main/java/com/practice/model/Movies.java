package com.practice.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;

import javax.persistence.GenerationType;

import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity

@Table(name = "movie_characters")

public class Movies {

	@Id

	@Column(name = "movie_id")

	@GeneratedValue(strategy = GenerationType.AUTO)

	private int movieId;

	@Column(name = "movie_name", nullable = false)

	private String name;

	@Column(name = "movie_length")

	private int moiveLength;

	@Column(name = "movie_genre")

	private String movieGenre;
	
	@ManyToOne (cascade = CascadeType.ALL,fetch = FetchType.LAZY)
	@JoinColumn(name="director_FK")
	private Directors dir; 
	
	@OneToOne(cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	@JoinColumn(name="planet_fk")
	private Planet planet;

	public int getMovieId() {
		return movieId;
	}

	public void setMovieId(int movieId) {
		this.movieId = movieId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getMoiveLength() {
		return moiveLength;
	}

	public void setMoiveLength(int moiveLength) {
		this.moiveLength = moiveLength;
	}

	public String getMovieGenre() {
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}

	public Directors getDir() {
		return dir;
	}

	public void setDir(Directors dir) {
		this.dir = dir;
	}

	public Planet getPlanet() {
		return planet;
	}

	public void setPlanet(Planet planet) {
		this.planet = planet;
	} 
	
	public Movies() {
	
	}

	public Movies(String name, int moiveLength, String movieGenre, Directors dir, Planet planet) {
		super();

		this.name = name;
		this.moiveLength = moiveLength;
		this.movieGenre = movieGenre;
		this.dir = dir;
		this.planet = planet;
	}
	
	

}