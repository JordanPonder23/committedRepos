package com.practice.driver;

import com.practice.daos.CharacterDAO;
import com.practice.model.MCharacters;

public class Driver {
	private static CharacterDAO  cdao = new CharacterDAO();  

	public static void main(String[] args) {
		
		MCharacters mc = new MCharacters();
		mc.setName("TomCruise");
		mc.setRole("MovieGuy");
		mc.setGender("Male");
		
		cdao.insert(mc);

	}

}
