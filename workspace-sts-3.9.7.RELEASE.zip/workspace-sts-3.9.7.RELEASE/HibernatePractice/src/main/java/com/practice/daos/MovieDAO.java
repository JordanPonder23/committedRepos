package com.practice.daos;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.util.HibernateUtil;
import com.practice.model.Movies;

public class MovieDAO {
	public MovieDAO() {

	}

	public void insert(Movies Movies) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.save(Movies);

		tx.commit();

//		ses.close();

	}

	public void update(Movies Movies) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.update(Movies);

		tx.commit();

//		ses.close();

	}

	public Movies selectById(int id) {

		Session ses = HibernateUtil.getSession();

		Movies Movies = ses.get(Movies.class, id);

//		ses.close();

		return Movies;

	}

	public Movies selectByName(String name) {

		return null;

	}

	public List<Movies> selectAll() {

		Session ses = HibernateUtil.getSession();

		List<Movies> MoviesList = ses.createQuery("from Movies", Movies.class).getResultList();

//		ses.close();

		return MoviesList;

	}
}
