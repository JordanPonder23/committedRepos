package myhogwarts.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import myhogwarts.model.Users;
import myhogwarts.repo.UserRepo;

@Controller
@CrossOrigin(origins = "*")
public class UserController {

	@Autowired
	private HttpSession httpSession;
	@Autowired
	private UserRepo userRepo;

	static String sessUser;
	public UserController() {
		super();
	}

	@RequestMapping(value = "/getAllUsers.app", method = RequestMethod.GET)
	public @ResponseBody List<Users> getAllUsers() {

		return userRepo.selectAll();

	}

	@RequestMapping(value = "/checkLogin.app", method = RequestMethod.POST)
	public @ResponseBody Users checkLogin(@RequestBody String username/* , HttpSession httpSession */) {

		System.out.println("inside of the check login app");
		System.out.println(username);

		Users userN = userRepo.getUserInfo(username);
		System.out.println(userN.getUsername());
		httpSession.setAttribute("loggedinUsername" , userN.getUsername());
		// httpSession.setAttribute("loggedinFirstName" , userN.getFirstname());
		// httpSession.setAttribute("loggedinLastName" , userN.getLastname());
		//httpSession.setAttribute("loggedinUsername", username);
		System.out.println("Still in checklogin");
		sessUser= (String) httpSession.getAttribute("loggedinUsername");
		System.out.println(sessUser);
		return userN;
	}

	@RequestMapping(value = "/userInfo.app", method = RequestMethod.GET)
	public @ResponseBody Users getUserInfo(/* HttpSession httpSession */) {
		System.out.println("inside of the userInfo app");
		
		//System.out.println((String) httpSession.getAttribute("loggedinUsername"));

		 Users userN = userRepo.getUserInfo(sessUser);

		// System.out.println(userN.getUsername());

		return userN;
	}


	@RequestMapping(value = "/register.app", method = RequestMethod.POST)
	public @ResponseBody Users registerUser(@RequestBody Users user) {

		Users user1 = new Users(user.getFirstname(), user.getLastname(), user.getUsername(), user.getPassword(),
				user.getEmail());

		userRepo.insert(user);

		return user;
	}
	
	@RequestMapping(value = "/logout.app", method = RequestMethod.POST)
	public void logout() {

		System.out.println("afskhjbdvkj");
		httpSession.invalidate();

		
	}

}
