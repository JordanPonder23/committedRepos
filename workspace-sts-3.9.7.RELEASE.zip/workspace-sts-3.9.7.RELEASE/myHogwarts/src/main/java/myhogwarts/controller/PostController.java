package myhogwarts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import myhogwarts.model.Posts;
import myhogwarts.repo.PostRepo;

@Controller
@CrossOrigin(origins ="*")
public class PostController {

	@Autowired
	private PostRepo postRepo;

	public PostController() {
		super();
	}

	@RequestMapping(value = "/getAllPosts.app", method = RequestMethod.GET)
	public @ResponseBody List<Posts> getAllPosts() {

		return postRepo.selectAll();

	}

	
	@RequestMapping(value = "/dothething.app", method = RequestMethod.POST)
	public @ResponseBody Posts postCharm(@RequestBody String charmData) {
		
		//current username
		String currUser=UserController.sessUser;
		
	//	User 
		System.out.println("making charm");
		Posts post = new Posts(charmData);

		System.out.println(post);
		postRepo.insert(post);

		return post;
	}
	
	@RequestMapping(value = "/postInfo.app", method = RequestMethod.GET)
	public @ResponseBody List<Posts> getPostsInfo(/* HttpSession httpSession */) {
		System.out.println("inside of the postInfo app");
		
		System.out.println("The sessUser is: " + UserController.sessUser);
		
		//System.out.println((String) httpSession.getAttribute("loggedinUsername"));

		// Users userN = userRepo.getUserInfo(sessUser);
		List<Posts> postList = postRepo.getUserPost(UserController.sessUser);
		
		System.out.println("The post list is: " + postList);

		// System.out.println(userN.getUsername());

		return postList;
	}
}
