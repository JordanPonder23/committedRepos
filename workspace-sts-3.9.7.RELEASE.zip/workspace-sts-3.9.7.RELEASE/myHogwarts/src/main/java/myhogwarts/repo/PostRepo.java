package myhogwarts.repo;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import myhogwarts.model.Posts;
import myhogwarts.model.Users;
import oracle.jdbc.proxy.annotation.Post;

@Repository("postRepo")
@Transactional
public class PostRepo {
	
	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	@Autowired
	private SessionFactory sesFact;

	public PostRepo() {

	}

	public void insert(Posts post) {
		sesFact.getCurrentSession().save(post);

	}

	public void update(Posts post) {
		sesFact.getCurrentSession().update(post);
	}

	public Posts selectById(int id) {
		return sesFact.getCurrentSession().get(Posts.class, id);

	}

	public List<Posts> selectAll() {
		return sesFact.getCurrentSession().createQuery("from Posts", Posts.class).list();
	}
	
	public void increaseLike() {
		//logic
	}
	
	public List<Posts> getUserPost(String username) {
		//System.out.println(sesFact.getCurrentSession());
		
		List<Users> userList = sesFact.getCurrentSession()
				.createQuery("from Users where username='" + username + "'", Users.class).list();
		
		Users user = userList.get(0);
		
		int userId = user.getUserID();
		
		System.out.println("The userId in post is: " + userId);
		
		List<Posts> postList = sesFact.getCurrentSession()
				.createQuery("from Posts where post_id = 2"/* + userId +"'" */, Posts.class).list();

		if (postList.size() == 0) {

			return null;
		}

		return postList;
	}


}
