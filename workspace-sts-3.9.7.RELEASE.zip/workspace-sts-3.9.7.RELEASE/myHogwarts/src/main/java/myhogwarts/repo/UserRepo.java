package myhogwarts.repo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import myhogwarts.model.Users;

@Repository("userRepo")
@Transactional
public class UserRepo {

	static {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Autowired
	private SessionFactory sesFact;

	public UserRepo() {

	}

	public void insert(Users user) {
		sesFact.getCurrentSession().save(user);

	}

	public void update(Users user) {
		sesFact.getCurrentSession().update(user);
	}

	public Users selectById(int id) {
		return sesFact.getCurrentSession().get(Users.class, id);

	}

	public List<Users> selectAll() {
		return sesFact.getCurrentSession().createQuery("from Users", Users.class).list();
	}

	public Users getUserInfo(String username) {
		System.out.println(sesFact.getCurrentSession());
		List<Users> userList = sesFact.getCurrentSession()
				.createQuery("from Users where username='" + username + "'", Users.class).list();

		if (userList.size() == 0) {

			return null;
		}

		return userList.get(0);
	}
	
	public Users getSingleUserInfo() {

		System.out.println(sesFact.getCurrentSession());
		//Users user = (Users) sesFact.getCurrentSession().get("Users", sesFact);

		return null;
	}

}
