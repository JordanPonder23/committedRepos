package myhogwarts.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="Users")
public class Users {

	@Id
	@Column(name = "user_Id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int userID;

	@Column(name = "user_firstname")
	private String firstname;

	@Column(name = "user_lastname")
	private String lastname;

	@Column(name = "user_username")
	private String username;

	@Column(name = "user_password")
	private String password;

	@Column(name = "user_profilePic")
	private String profilePic;

	@Column(name = "user_coverPhoto")
	private String coverPhoto;

	@Column(name = "user_email")
	private String email;

	@Column(name = "user_birthdate")
	private String birthdate;

	@Column(name = "user_house")
	private String userHouse;

	@Column(name = "user_pet")
	private String userPet;

	@Column(name = "user_wandType")
	private String wandType;

	@Column(name = "user_favorite_spell")
	private String favoriteSpell;

	@OneToMany(mappedBy = "userVar", fetch = FetchType.EAGER)
	private List<Posts> postList = new ArrayList<>();

	public Users() {
		super();
	}
	
	

	public Users(String firstname, String lastname, String username, String password, String email) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
		this.email = email;
	}



	public Users(String firstname, String lastname, String username, String password, String profilePic,
			String coverPhoto, String email, String birthdate, String userHouse, String userPet, String wandType,
			String favoriteSpell) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
		this.profilePic = profilePic;
		this.coverPhoto = coverPhoto;
		this.email = email;
		this.birthdate = birthdate;
		this.userHouse = userHouse;
		this.userPet = userPet;
		this.wandType = wandType;
		this.favoriteSpell = favoriteSpell;
	}

	public Users(int userID, String firstname, String lastname, String username, String password, String profilePic,
			String coverPhoto, String email, String birthdate, String userHouse, String userPet, String wandType,
			String favoriteSpell, List<Posts> postList) {
		super();
		this.userID = userID;
		this.firstname = firstname;
		this.lastname = lastname;
		this.username = username;
		this.password = password;
		this.profilePic = profilePic;
		this.coverPhoto = coverPhoto;
		this.email = email;
		this.birthdate = birthdate;
		this.userHouse = userHouse;
		this.userPet = userPet;
		this.wandType = wandType;
		this.favoriteSpell = favoriteSpell;
		this.postList = postList;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfilePic() {
		return profilePic;
	}

	public void setProfilePic(String profilePic) {
		this.profilePic = profilePic;
	}

	public String getCoverPhoto() {
		return coverPhoto;
	}

	public void setCoverPhoto(String coverPhoto) {
		this.coverPhoto = coverPhoto;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getUserHouse() {
		return userHouse;
	}

	public void setUserHouse(String userHouse) {
		this.userHouse = userHouse;
	}

	public String getUserPet() {
		return userPet;
	}

	public void setUserPet(String userPet) {
		this.userPet = userPet;
	}

	public String getWandType() {
		return wandType;
	}

	public void setWandType(String wandType) {
		this.wandType = wandType;
	}

	public String getFavoriteSpell() {
		return favoriteSpell;
	}

	public void setFavoriteSpell(String favoriteSpell) {
		this.favoriteSpell = favoriteSpell;
	}

	public List<Posts> getPostList() {
		return postList;
	}

	public void setPostList(List<Posts> postList) {
		this.postList = postList;
	}

	@Override
	public String toString() {
		return "\nUsers [userID=" + userID + ", firstname=" + firstname + ", lastname=" + lastname + ", username="
				+ username + ", password=" + password + ", profilePic=" + profilePic + ", coverPhoto=" + coverPhoto
				+ ", email=" + email + ", birthdate=" + birthdate + ", userHouse=" + userHouse + ", userPet=" + userPet
				+ ", wandType=" + wandType + ", favoriteSpell=" + favoriteSpell + ", postList=" + postList + "]";
	}

}
