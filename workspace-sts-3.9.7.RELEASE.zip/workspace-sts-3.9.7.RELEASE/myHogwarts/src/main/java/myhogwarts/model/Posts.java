package myhogwarts.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="Posts")
public class Posts {
	
	@Id
	@Column(name="post_Id")
	@GeneratedValue(strategy =GenerationType.AUTO)
	private int postId;
	
	@Column(name="post_image")
	private String postImage;
	
	@Column(name="post_description")
	private String postDescription;
	
	@Column(name="post_timestamp")
	private String postTime;
	/*
	 * @Column(name="like_count") private int likeCount = 0;
	 */
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="user_Id_FK")
	private Users userVar;

	public Posts() {
		super();
	}

	public Posts(String postDescription) {
		super();
		this.postDescription = postDescription;
	}

	
	
	public Posts(String postDescription, Users userVar) {
		super();
		this.postDescription = postDescription;
		this.userVar = userVar;
	}

	public Posts(String postImage, String postDescription, String postTime, Users userVar) {
		super();
		this.postImage = postImage;
		this.postDescription = postDescription;
		this.postTime = postTime;
		//this.likeCount = likeCount;
		this.userVar = userVar;
	}

	public Posts(int postId, String postImage, String postDescription, String postTime, int likeCount, Users userVar) {
		super();
		this.postId = postId;
		this.postImage = postImage;
		this.postDescription = postDescription;
		this.postTime = postTime;
	//	this.likeCount = likeCount;
		this.userVar = userVar;
	}

	public int getPostId() {
		return postId;
	}

	public void setPostId(int postId) {
		this.postId = postId;
	}

	public String getPostImage() {
		return postImage;
	}

	public void setPostImage(String postImage) {
		this.postImage = postImage;
	}

	public String getPostDescription() {
		return postDescription;
	}

	public void setPostDescription(String postDescription) {
		this.postDescription = postDescription;
	}

	public String getPostTime() {
		return postTime;
	}

	public void setPostTime(String postTime) {
		this.postTime = postTime;
	}

	public Users getUserVar() {
		return userVar;
	}

	public void setUserVar(Users userVar) {
		this.userVar = userVar;
	}


	@Override
	public String toString() {
		return "Posts [postId=" + postId + ", postImage=" + postImage + ", postDescription=" + postDescription
				+ ", postTime=" + postTime + ", likeCount=" + ", userVar=" + userVar + "]";
	}

}

