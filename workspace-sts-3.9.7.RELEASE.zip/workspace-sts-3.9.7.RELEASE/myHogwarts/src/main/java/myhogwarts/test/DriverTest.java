package 	myhogwarts.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import myhogwarts.model.Posts;
import myhogwarts.model.Users;
import myhogwarts.repo.PostRepo;
import myhogwarts.repo.UserRepo;

public class DriverTest {
	public static ApplicationContext appCont = new ClassPathXmlApplicationContext("applicationContext.xml");
	public static UserRepo userRepo = appCont.getBean("userRepo", UserRepo.class);
	public static PostRepo postRepo = appCont.getBean("postRepo", PostRepo.class);

	public static void main(String[] args) {

		/* insertInitialValues(); */
		
		//System.out.println("The list of users: " + userRepo.selectAll());
		
		System.out.println("The current user is: " + userRepo.getUserInfo("giovanni"));

		//System.out.println("all of our users: " + userRepo.selectAll());

	}

	public static void insertInitialValues() {
		Users user = new Users();
		user.setFirstname("Hagrid");
		user.setLastname("Stuff");
		user.setUsername("hagridddd");
		user.setPassword("beard");

		Users user2 = new Users();

		user2.setFirstname("Ron");
		user2.setLastname("Weasley");
		user2.setBirthdate("911");
		user2.setFavoriteSpell("Alohamora");
		
		Posts post = new Posts();
		post.setPostDescription("HELLOO GIO IS THIS DESCRIPTION WORKING");
		
		postRepo.insert(post);

		userRepo.insert(user);
		userRepo.insert(user2);
		System.out.println("after insert");

	}
}
