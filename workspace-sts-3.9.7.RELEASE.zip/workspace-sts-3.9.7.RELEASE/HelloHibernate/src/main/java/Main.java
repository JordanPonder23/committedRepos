import java.util.ArrayList;
import java.util.List;

import com.example.dao.CrimeDAO;
import com.example.dao.SuperVillainDAO;
import com.example.model.Crime;
import com.example.model.SuperVillain;

public class Main {
	static SuperVillainDAO svdao = new SuperVillainDAO(); 
	static CrimeDAO cdao = new CrimeDAO();
	
	public static void main(String[] args) {
			insertInitialValues();
			
			System.out.println("select by id 2: " +svdao.selectById(2));
			System.out.println("ALL VILLAINS: ");
			System.out.println("\t"+svdao.selectAll()+"\n");
			System.out.println("done");
	}
	public static void insertInitialValues() {
		
	Crime crim1 = new Crime("Aggregated", "lordy");
	Crime crim3 = new Crime("throat punching", "wow");
	Crime crim4 = new Crime("icecream", "asdf");
	Crime crim5 = new Crime("throat punching", "df");
	Crime crim6 = new Crime("oatmeal cookies", "safsd");
	
	cdao.insert(crim1);
	cdao.insert(crim3);
	cdao.insert(crim4);
	cdao.insert(crim6);
	
	
	List<Crime> crimeList = new ArrayList<>();
	
	crimeList.add(crim1);
	crimeList.add(crim5);
	SuperVillain vill1 = new SuperVillain("R Connell", "Hacking", 1, crimeList);
	crimeList = new ArrayList<>(); 
	crimeList.add(crim6);
	//SuperVillain vill2 = new SuperVillain();
	svdao.insert(vill1);
	
//		SuperVillain vill = new SuperVillain(6998,"ScreenSlaver", "Hypnotism", 45_000);
//		svdao.insert(vill);
		
//		vill = new SuperVillain("Syndrome", "Power Remote", 25_000); 
//		svdao.insert(vill);
//		vill = new SuperVillain("Joker", "Infectious laugh", 123_500); 
//		svdao.insert(vill);
//		vill = new SuperVillain("Aquaman", "Throat punch", 99_000); 
//		svdao.insert(vill);
//		vill = new SuperVillain("Dirty Bubble", "filfth", 49_000); 
//		svdao.insert(vill);
	}
}
