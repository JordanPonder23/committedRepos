package com.example.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="SuperVillain")
public class SuperVillain {
	
	@Id
	@Column(name ="svill_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int svillId; 
	
	@Column(name= "name", unique = true, nullable=false)
	private String name; 
	
	@Column(name ="superpower")
	private String superpower;
	
	@Column(name="bounty")
	private int bounty;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<Crime> crimes; 
	
	
	public SuperVillain() {
		
	}
	
	

	public SuperVillain(int svillId, String name, String superpower, int bounty, List<Crime> crimes) {
		super();
		this.svillId = svillId;
		this.name = name;
		this.superpower = superpower;
		this.bounty = bounty;
		this.crimes = crimes;
	}
	public SuperVillain( String name, String superpower, int bounty, List<Crime> crimes) {
		super();
		
		this.name = name;
		this.superpower = superpower;
		this.bounty = bounty;
		this.crimes = crimes;
	}


	@Override
	public String toString() {
		return "SuperVillain [svillId=" + svillId + ", name=" + name + ", superpower=" + superpower + ", bounty="
				+ bounty + "]";
	}

	
	
	public List<Crime> getCrimes() {
		return crimes;
	}

	public void setCrimes(List<Crime> crimes) {
		this.crimes = crimes;
	}

	public int getSvillId() {
		return svillId;
	}
	public void setSvillId(int svillId) {
		this.svillId = svillId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSuperpower() {
		return superpower;
	}
	public void setSuperpower(String superpower) {
		this.superpower = superpower;
	}
	public int getBounty() {
		return bounty;
	}
	public void setBounty(int bounty) {
		this.bounty = bounty;
	} 
	
	
	
	
}
