package com.example.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Super_Prison")
public class SuperPrison {
	@Id
	@Column(name="sp_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int spid; 
	@Column(name="sp_Name")
	private String spName; 
	@Column(name="sp_Location")
	private String spLocation; 
	
	public SuperPrison() {
		// TODO Auto-generated constructor stub
	}
	public SuperPrison( String spName, String spLocation) {
		super();
	
		this.spName = spName;
		this.spLocation = spLocation;
	}
	public SuperPrison(int spid, String spName, String spLocation) {
		super();
		this.spid = spid;
		this.spName = spName;
		this.spLocation = spLocation;
	}
	
	
}
