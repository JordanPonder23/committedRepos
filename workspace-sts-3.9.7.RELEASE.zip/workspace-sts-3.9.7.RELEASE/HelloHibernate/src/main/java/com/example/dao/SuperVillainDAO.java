package com.example.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;


import com.example.model.SuperVillain;
import com.example.util.HibernateUtil;



public class SuperVillainDAO {
	
	
	public SuperVillainDAO() {
		
	}
	
	public void insert(SuperVillain myVill) {
		Session sesh = HibernateUtil.getSession(); 
		Transaction tx = sesh.beginTransaction(); 
		
		sesh.save(myVill);
		tx.commit();
		sesh.close();
	}
	public void update(SuperVillain myVill) {
		Session sesh = HibernateUtil.getSession(); 
		Transaction tx = sesh.beginTransaction(); 
		
		sesh.update(myVill);
		tx.commit();
		sesh.close();
	}
	public SuperVillain selectById(int id) {
		
		Session sesh = HibernateUtil.getSession(); 
		
		SuperVillain myVill = sesh.get(SuperVillain.class, id);
		//get is the select query for select by id. 
		sesh.close();
		
		return myVill; 
	}
	public SuperVillain selectByName(String name) {
		
		Session ses = HibernateUtil.getSession(); 
		List<SuperVillain> villList = ses.createQuery("from SuperVillain where name ="+name, SuperVillain.class).list();
		
		if(villList.size()==0) {
			System.out.println("panic!!!");
			return null; 
		}
		
		return villList.get(0); 
	}
	public List<SuperVillain> selectAll(){
		Session sesh = HibernateUtil.getSession(); 
		
		List<SuperVillain> villList = sesh.createQuery("from SuperVillain", SuperVillain.class).list();
		//get is the select query for select by id. 
		sesh.close();
		
		return villList; 
	}
	
}
