package com.example.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.model.Crime;
import com.example.model.SuperVillain;
import com.example.util.HibernateUtil;

public class CrimeDAO {

	public CrimeDAO() {
		
	}

	public void insert(Crime crim1) {
		Session sesh = HibernateUtil.getSession();
		Transaction tx = sesh.beginTransaction();

		sesh.save(crim1);
		tx.commit();
		sesh.close();
	}

	public void update(Crime myVill) {
		Session sesh = HibernateUtil.getSession();
		Transaction tx = sesh.beginTransaction();

		sesh.update(myVill);
		tx.commit();
		sesh.close();
	}

	public Crime selectById(int id) {

		Session sesh = HibernateUtil.getSession();

		Crime myVill = sesh.get(Crime.class, id);
		// get is the select query for select by id.
		sesh.close();

		return myVill;
	}

	public Crime selectByName(String name) {

		return null;
	}

	public List<Crime> selectAll() {
		Session sesh = HibernateUtil.getSession();

		List<Crime> villList = sesh.createQuery("from Crime", Crime.class).list();
		// get is the select query for select by id.
		sesh.close();

		return villList;
	}
}
