package com.example.servlets;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.practice.daos.CharacterDAO;
import com.practice.model.MCharacters;

/**
 * Servlet implementation class MyServlet
 */
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static CharacterDAO svilldao = new CharacterDAO();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MyServlet() {
		System.out.println("before insert initial values call.. ");
		insertInitialValues();

	}

	public static void insertInitialValues() {
		System.out.println("called insert initialvalues successfully");
		// villains

		MCharacters vill1=new MCharacters("fart","boy", "fart", null) ;

		MCharacters vill2=new MCharacters("fart2","nongenderary", "fart", null);

		MCharacters vill3=new MCharacters("fart2","fart-kind", "movieroleactor", null);

		svilldao.insert(vill1);

		svilldao.insert(vill2);

		svilldao.insert(vill3);

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		System.out.println("I'm inside of the doGet");

		System.out.println("Characters: ");

		System.out.println("\t" + svilldao.selectAll() + "\n");

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		System.out.println("I'm inside of the doPost");

		System.out.println("Characters: ");

		System.out.println("\t" + svilldao.selectAll() + "\n");

	}

}
