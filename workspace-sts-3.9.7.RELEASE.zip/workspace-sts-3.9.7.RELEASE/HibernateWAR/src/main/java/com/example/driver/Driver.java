package com.example.driver;

import com.practice.daos.CharacterDAO;
import com.practice.model.MCharacters;

public class Driver {
	private static CharacterDAO svilldao = new CharacterDAO();
	
	public static void main(String[] args) {		
		
	}
	public static void insertInitialValues() {
		System.out.println("called insert initialvalues successfully");
		// villains

		MCharacters vill1=new MCharacters("fart","boy", "fart", null) ;

		MCharacters vill2=new MCharacters("fart2","nongenderary", "fart", null);

		MCharacters vill3=new MCharacters("fart2","fart-kind", "movieroleactor", null);

		svilldao.insert(vill1);

		svilldao.insert(vill2);

		svilldao.insert(vill3);

	}
}
