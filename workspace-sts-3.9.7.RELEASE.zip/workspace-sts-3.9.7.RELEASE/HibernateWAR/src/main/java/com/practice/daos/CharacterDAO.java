package com.practice.daos;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.example.util.HibernateUtil;
import com.practice.model.MCharacters;

public class CharacterDAO {
	static {

		try {

			Class.forName("oracle.jdbc.driver.OracleDriver");

		} catch (ClassNotFoundException e) {

			e.printStackTrace();

		}

	}

	public void insert(MCharacters character) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.save(character);

		tx.commit();
	}

	public void update(MCharacters character) {

		Session ses = HibernateUtil.getSession();

		Transaction tx = ses.beginTransaction();

		ses.update(character);

		tx.commit();
	}

	public MCharacters selectById(int id) {

		Session ses = HibernateUtil.getSession();

		MCharacters MCharacters = ses.get(MCharacters.class, id);

		return MCharacters;
	}

	public MCharacters selectByName(String name) {

		return null;
	}

	public List<MCharacters> selectAll() {

		Session ses = HibernateUtil.getSession();

		List<MCharacters> MCharactersList = ses.createQuery("from MCharacters", MCharacters.class).list();

		return MCharactersList;
	}

}
