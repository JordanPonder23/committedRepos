package com.practice.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name ="Directors")
public class Directors {
	
		@Id
		@Column(name="d_Id")
		@GeneratedValue(strategy =GenerationType.AUTO)
		private int dID;
		
		@Column(name="Movies_Directed")
		private int moviesDirected;
		
		@Column(name="age")
		private int age; 
		
		@Column(name ="best_movie")
		private String bestMovie; 
		
		@OneToMany(mappedBy ="dir", fetch = FetchType.LAZY)
		private List<Movies> movList = new ArrayList<Movies>();

		public int getdID() {
			return dID;
		}

		public void setdID(int dID) {
			this.dID = dID;
		}

		public int getMoviesDirected() {
			return moviesDirected;
		}

		public void setMoviesDirected(int moviesDirected) {
			this.moviesDirected = moviesDirected;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}

		public String getBestMovie() {
			return bestMovie;
		}

		public void setBestMovie(String bestMovie) {
			this.bestMovie = bestMovie;
		}

		public List<Movies> getMovList() {
			return movList;
		}

		public void setMovList(List<Movies> movList) {
			this.movList = movList;
		}
				
		public Directors() {
			
		}

		public Directors(int moviesDirected, int age, String bestMovie, List<Movies> movList) {
			super();
			this.moviesDirected = moviesDirected;
			this.age = age;
			this.bestMovie = bestMovie;
			this.movList = movList;
		}
		
		
}
