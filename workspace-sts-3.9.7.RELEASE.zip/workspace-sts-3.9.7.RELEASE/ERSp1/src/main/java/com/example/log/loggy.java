package com.example.log;

import org.apache.log4j.Logger;

public class loggy {
	public final static Logger logger = Logger.getLogger(loggy.class);	
}
