package com.JUnit.testing;

public class JTest {
	
}
