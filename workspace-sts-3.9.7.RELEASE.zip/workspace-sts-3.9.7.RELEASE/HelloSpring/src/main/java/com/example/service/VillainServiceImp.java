package com.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.model.SuperVillain;
import com.example.repository.DAOimpl;
import com.example.repository.VillainDao;

public class VillainServiceImp implements VillainService {
	//THIS IS THE OLD WAY OF DOING THINGS WITHOUT DI
//	private VillainDao villainDao = new DAOimpl(); 
	
	//DI
	private VillainDao villainDao;
	public static int counter = 0; 
	
	
	public VillainServiceImp() {
			System.out.println("in no args constructor");
	}
	
	
	public VillainServiceImp(DAOimpl vildao) {
		System.out.println("1 args constructor");
		this.villainDao = vildao;
	}	
	
	
	public VillainServiceImp(DAOimpl vildao, int number) {
		System.out.println("2 args constructor");
		this.villainDao = vildao;
	}	
	
	
	public VillainServiceImp(int number, DAOimpl vildao) {
		System.out.println(" ANOTHER 2 args constructor");
		this.villainDao = vildao;
		counter++;
	}	
	@Override
	public List<SuperVillain> getAllVills() {
		
		return villainDao.selectAll();
	}
	
		//OUR GETTERS AND SETTERS
	public VillainDao getVillainDao() {
		return villainDao;
	}
	@Autowired
	public void setVillainDao(VillainDao villainDao) {
		System.out.println("the villainDao object is set here");
		this.villainDao = villainDao;
	}
	

}
