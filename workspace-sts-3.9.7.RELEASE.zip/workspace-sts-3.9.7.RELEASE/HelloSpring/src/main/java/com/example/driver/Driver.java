package com.example.driver;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.example.service.VillainService;
import com.example.service.VillainServiceImp;

public class Driver {
	//old way of doing things.. 
//	private static VillainService villServe = new VillainServiceImp(); 
		//with DI 
	private static VillainService villServ; 
	
	public static void main(String[] args) {
		//remember ApplicationContext class ( you should be fine) 
		//  import org.springframework.context.ApplicationContext;
			ApplicationContext appContext = new ClassPathXmlApplicationContext("beans.xml");
			
			villServ = appContext.getBean("villServe", VillainService.class);
			
			appContext.getBean("villServe", VillainService.class);
					appContext.getBean("villServe", VillainService.class);
							appContext.getBean("villServe", VillainService.class);
							//get bean, by default returns a singleton... 
							// no matter how many times you type it, you're only going 
							// to get the same single instance of an object everytime. ( by default) 
							
//			new VillainServiceImp();
//			new VillainServiceImp();

			cleanPrint(villServ.getAllVills()); 
			System.out.println(" how many objects did we reate: "+VillainServiceImp.counter);
	}
		// this method makes a printed list more readable in the console. 
	public static <t> void cleanPrint(List<t> myList) {
		System.out.println("The list : " );
		for (t listItem : myList) {
			System.out.println(listItem);
		}
	}
}
