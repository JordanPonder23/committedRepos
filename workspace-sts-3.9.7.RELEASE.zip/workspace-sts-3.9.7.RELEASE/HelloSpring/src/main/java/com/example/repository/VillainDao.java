package com.example.repository;

import java.util.List;

import com.example.model.SuperVillain;

public interface VillainDao {
	public List<SuperVillain> selectAll(); 
}
