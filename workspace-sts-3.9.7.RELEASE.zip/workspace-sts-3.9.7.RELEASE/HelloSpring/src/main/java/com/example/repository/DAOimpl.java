package com.example.repository;

import java.util.ArrayList;
import java.util.List;

import com.example.model.SuperVillain;

public class DAOimpl implements VillainDao{
/*
 * this method is a mock Dao implementation. 
 * instead of going to a database it has a hardcoded list of villains. 
 */
	
	@Override
	public List<SuperVillain> selectAll() {
		List<SuperVillain> vills = new ArrayList<>();
		vills.add(new SuperVillain("Fartman","Techno", 9));
		vills.add(new SuperVillain("Cyborg","Street", 92));
		vills.add(new SuperVillain("Character3","Wolfs", 302));
		vills.add(new SuperVillain("Sanjaya","Wolfs", 8902));		

		return vills;
	}
	
}
