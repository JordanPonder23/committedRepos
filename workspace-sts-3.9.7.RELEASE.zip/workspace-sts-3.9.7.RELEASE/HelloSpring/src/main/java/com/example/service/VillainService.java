package com.example.service;

import java.util.List;

import com.example.model.SuperVillain;

public interface VillainService {
		List<SuperVillain> getAllVills(); 
}
