package com.example.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.OracleDriver;

public class ConnectionManager {
//	static{
//		System.out.println("oracle driver being declared");
//	       try {
//
//	           Class.forName("oracle.jdbc.driver.OracleDriver");
//	           	System.out.println("oracle driver being declared");
//	       } catch (ClassNotFoundException e) {
//
//	           e.printStackTrace();
//
//	       }
//
//	   }
	
	private static String url= "jdbc:oracle:thin:@jponder23.cv1rmjxwr5fp.us-east-2.rds.amazonaws.com:1521:orcl";

	private static String username="accessorman";

	private static String password= "password23";
//	   public static Connection getConnection() throws SQLException{
//		   
//
//System.out.println("inside get connection! ");
//	        String url = "jdbc:oracle:thin:@jponder23.cv1rmjxwr5fp.us-east-2.rds.amazonaws.com:1521:orcl";
//
//	        String username = "myusfdb";
//
//	        String password = "#3Marine33";
//
//	        OracleDriver driver = new OracleDriver();
//
//	        DriverManager.registerDriver(driver);
//
//	        return DriverManager.getConnection(url, username, password);
//
//	    }
	//--==========================\
	public static String getUrl() {
		return url;
	}
	public static void setUrl(String url) {
		ConnectionManager.url = url;
	}
	public static String getUsername() {
		return username;
	}
	public static void setUsername(String username) {
		ConnectionManager.username = username;
	}
	public static String getPassword() {
		return password;
	}
	public static void setPassword(String password) {
		ConnectionManager.password = password;
	}
	//--/
	
		public static void registerNamePassword(String insrtStmnt) {
			 
			ConnectionManager cm = new ConnectionManager(); 
			try(Connection conn =
					DriverManager.getConnection(cm.getUrl(), cm.getUsername(), cm.getPassword()))
			{
				System.out.println("executing... ");
				Statement statement = conn.createStatement();
				int numOfRowsChanged = statement.executeUpdate(insrtStmnt);
				
			}catch(SQLException e) {
				e.printStackTrace();
			}
			
		}
}
