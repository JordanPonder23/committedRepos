package com.example.servlet;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MasterServlet
 */
public class MasterServlet extends HttpServlet {

    public MasterServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("in the doGET");
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		System.out.println("in the doPOST");
		System.out.println(" Full Name: " + request.getParameter("fullName"));
		//System.out.println("  Password: "+request.getParameter("password"));
		String fullName = request.getParameter("fullName"); 
		// separate full name parts
		ArrayList<String> splitName = new ArrayList<>(); // people might have multiple parts to their name
		System.out.println("wtf");
		int numberOfnames = 0; 
		String[] splitter = fullName.split("\\s");
		for(String st : splitter) {
			splitName.add("'"+st+"'"+",");
			System.out.println(st);
			numberOfnames++; 
		}
		int tempIndex = numberOfnames; 
		while(tempIndex<5) {
			splitName.add(" ");//I don't think a space can hurt the insert statement..let's see..
			tempIndex++; 
		}
		
		/////	====DETERMINE COLUMNS FOR INSERT======
		System.out.println("numberOfNames:  " +numberOfnames );
		ArrayList<String> midNms = new ArrayList<>();
		String mNm1="middleName1,";
		String mNm2="middleName2,";
		String mNm3="middleName3,";
		midNms.add(mNm1);
		midNms.add(mNm2);
		midNms.add(mNm3);
		int index =numberOfnames-2;
			while(index <3) {
				midNms.remove(index);
				midNms.add(index-1, "");//should nullify that spot
				index++; 
			}
			///======Build insert Query------
//			for(String st: midNms) { //test- if there is only two middle names, columns middleName1 and middleName3 will be used
//		System.out.println(st);		// test- if there is only one middle name, column middleName2 will be used only
//			}						// test- if there are three then, all three columns will be used ( middleName1, middleName2, middleName3)
	///--TEST/ Counting number of middle name columns to use ^^ ---	
			String password =request.getParameter("password");
			//-----values for columns (password and first name are given but we have to work out how many middle names the included-
						
			//-the user-name will be a combination of the last name and first name with some "random" mixed in- 
			
			
		String insertQ = "insert into Members(UserIdentity, Password_, first_Name,"+midNms.get(0)+midNms.get(1)+midNms.get(2)+"last_Name, gender)"
				+ " values(MemberID.NEXTVAL, '"+password+"', "+splitName.get(0)+splitName.get(1)+splitName.get(2)+splitName.get(3)+splitName.get(4)+"'notAssumed')";
		//=-=-=()---0--O-o~      
	//	ConnectionManager cm = new ConnectionManager(); 
//		try {
//			cm.getConnection();
//			System.out.println("inside getConnection");
//		} catch (SQLException e) {
//		
//			//e.printStackTrace();
//			System.out.println("get connection failed!!");
//		}
	//	cm.registerNamePassword(insertQ);//this is, currently, where the call to database is, right now... 
		System.out.println("query built: " +insertQ);
	//	System.out.println("Password:  "+password);
		//doGet(request, response);

	}
}
