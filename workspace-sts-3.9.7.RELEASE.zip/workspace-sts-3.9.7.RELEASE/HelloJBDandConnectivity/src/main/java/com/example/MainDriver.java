package com.example;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class MainDriver{
	
	private static String url= "jdbc:oracle:thin:ACTUALCONNECTIONSTRING:1521:orcl";

			private static String username="testuser";

			private static String password= "password1";	
	
	public static void main(String[] args) {
		statementExample(url,"1","person");
	}
	public static void statementExample(String url, String id, String namingAttmept) {

		try(Connection conn =
				DriverManager.getConnection(url, id, namingAttmept))
		{
			String sql = "INSERT INTO CustTable(Cid, FirstName) "+
					"VALUES('" + id+"', '" + namingAttmept+ "' )";
			Statement statement = conn.createStatement();
			int numOfRowsChanged = statement.executeUpdate(sql);
			System.out.println("The # of rows changed: "+ numOfRowsChanged);
			
		}catch(SQLException e) {
			e.printStackTrace();
		}
	}
}


//
//
//
//import java.sql.CallableStatement;
//import java.sql.Connection;
//
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//
//import java.sql.Statement;
//
//
//public class MainDriver {
//
//	/*private static String url=
//
//			"jdbc:oracle:thin:@localhost:1521:xe";*/
//
//	private static String url="jdbc:oracle:thin:jponder23.cv1rmjxwr5fp.us-east-2.rds.amazonaws.com:1521:orcl";
//
//	private static String username=
//
//				"foodUser";
//
//	private static String password=
//
//				"p4ssw0rd";
//
//	public static void main(String[] args) {
//
//		// TODO Auto-generated method stub
//
//		statementExample("dressing", "grandmas love");
//
//		System.out.println("done");
//		prepareStatement("String1", "String2");
//		
//
//	}
//	//preparad statements --- 
//		
//		public static void prepareStatement(String f_name, String f_recipe) {
//			try(Connection conn =
//					DriverManager.getConnection(url, username, password))
//			{
//				String sql = "INSERT INTO food(food_name, recipe) "+
//						"VALUES(?,?)";
//				
//					PreparedStatement ps= conn.prepareStatement(sql);
//					ps.setString(1, f_name);   //start at 1 NOT zero.. 
//					ps.setString(2, f_recipe);
//					ps.executeUpdate();
//			
//			}catch(SQLException e) {
//				e.printStackTrace();
//			}
//		}
//		
//	//statements==============
//
//	public static void statementExample(String f_name, String f_recipe) {
//
//		try(Connection conn =
//
//				DriverManager.getConnection(url, username, password))
//
//		{
//
//			String sql = "INSERT INTO food(food_name, recipe) "+
//
//					"VALUES('" + f_name+"', '" + f_recipe+ "' )";
//
//			Statement statement = conn.createStatement();
//
//			int numOfRowsChanged = statement.executeUpdate(sql);
//
//			System.out.println("The # of rows changed: "+ numOfRowsChanged);
//
//		}catch(SQLException e) {
//
//			e.printStackTrace();
//
//		}
//
//	}
//	//callable statement.. 
//	public static void callableStatementExample(String ex, String ex2) {
//		try(Connection conn =
//
//				DriverManager.getConnection(url, username, password))
//
//		{
//
//			String sql = "{ procedure(?,?) }";
//			
//			CallableStatement cs = conn.prepareCall(sql);
//			cs.setString(1, ex);
//			cs.setString(2, ex2);
//			int status = cs.executeUpdate();
//			System.out.println("callable statement returns: " + status); // 
//			
//		}catch(SQLException e) {
//
//			e.printStackTrace();
//
//		}
//
//	}
//	}
//	
//


