package com.example.driver;

import com.example.dao.SuperVillainDao;
import com.example.model.SuperVillain;

public class Driver {
	private static SuperVillain sv = new SuperVillain(); 
	private static SuperVillainDao svdao = new SuperVillainDao(); 
	public static void main(String[] args) {
		
		sv.setBounty(400);
		sv.setName("Super Satan");
		sv.setSuperpower("slander");
		
		svdao.insert(sv);
		svdao.selectAll();
	}

}
